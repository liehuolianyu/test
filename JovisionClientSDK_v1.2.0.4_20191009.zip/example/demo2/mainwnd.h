﻿
#pragma once

#include "event.h"
#include "jcsdk.h"

namespace Ui
{
    class mainwnd;
}

class mainwnd : public QDialog
{
    Q_OBJECT

public:
    explicit mainwnd(QWidget *parent = 0);
    ~mainwnd();

public:
    bool Init();
    void Release();

	int GetLinkID() const
	{
		return m_nLinkID;
	}

    void AddLogItem(const char* szLog);

	virtual void moveEvent(QMoveEvent* event);
    virtual void customEvent(QEvent *event);

private slots:
    void OnConnect();
    void OnDisconnect();
    void OnRemoteCfg();
    void OnDevSearch();

    void OnStartDecode();
    void OnStopDecode();
    void OnStartPreview();
    void OnStopPreview();
    void OnGetPicture();

    void OnStartRec();
    void OnStopRec();
    void OnStartAudio();
    void OnStopAudio();
    void OnGetRecFileList();

    void OnSpeedUp();
    void OnSpeedDown();
    void OnSpeedNormal();
    void OnSpeedPause();
    void OnDownload();

    void OnEnableStream();
    void OnDisableStream();
	void OnStartTalk();
	void OnStopTalk();
	void OnOneKeyIP();

private:
    Ui::mainwnd *ui;

    JCLink_t m_nLinkID;
    bool m_bPreview;
    bool m_bDecoding;
    bool m_bPreviewing;
};
