﻿
#include "mainwnd.h"

QApplication* g_pMainApp = NULL;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    g_pMainApp = &a;

	QTranslator translator;
	bool b = false;
	//b = translator.load("cn.qm");
	b = translator.load("en.qm");
	a.installTranslator(&translator);

    mainwnd w;
    if(!w.Init())
    {
        return -1;
    }
    w.show();
    int nRet = a.exec();
    w.Release();

    return nRet;
}
