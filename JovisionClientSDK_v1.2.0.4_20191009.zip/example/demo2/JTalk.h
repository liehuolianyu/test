//dll�Ľӿ�  
//#if !defined(AFX_INTERFACE_H__DEB6C49D_7068_4289_9538_44E531D90376__INCLUDED_)
//#define AFX_INTERFACE_H__DEB6C49D_7068_4289_9538_44E531D90376__INCLUDED_
#ifndef _INTERFACE_H
#define _INTERFACE_H

#define JVCHAT_API extern "C" __declspec(dllexport)

typedef void (*FUNC_SENDDATA_CALLBACK)(char *pBuffer, int m_iLen);

#define JVT_CODECTYPE_g729a_8k16b	0
#define JVT_CODECTYPE_pcm_8k8b		1
#define	JVT_CODECTYPE_g711a_8k16b	2
#define	JVT_CODECTYPE_g711u_8k16b	3

JVCHAT_API BOOL _stdcall IniTalk(DWORD dwCodecType);
JVCHAT_API BOOL _stdcall EndTalk();

JVCHAT_API void _stdcall SendVoliceDataIn(char *pBuffer, int m_iLen);
JVCHAT_API void _stdcall SendVoliceDataOut(char *pBuffer, int m_iLen);

JVCHAT_API void _stdcall JVA_RegisterCallBack(FUNC_SENDDATA_CALLBACK SendDataCallBack);

#endif // !defined(AFX_INTERFACE_H__DEB6C49D_7068_4289_9538_44E531D90376__INCLUDED_)
