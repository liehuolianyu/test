<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>finddevicedlg</name>
    <message>
        <location filename="finddevicedlg.ui" line="14"/>
        <source>设备检索</source>
        <translation>设备检索</translation>
    </message>
    <message>
        <location filename="finddevicedlg.ui" line="26"/>
        <source>刷新</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="finddevicedlg.ui" line="58"/>
        <source>重设IP</source>
        <translation>重设IP</translation>
    </message>
</context>
<context>
    <name>mainwnd</name>
    <message>
        <location filename="mainwnd.ui" line="14"/>
        <source>Demo</source>
        <translation>Demo</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="60"/>
        <source>云视通</source>
        <translation>云视通</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="96"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="122"/>
        <source>端口</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="146"/>
        <source>通道号</source>
        <translation>通道号</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="169"/>
        <source>用户名</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="182"/>
        <source>密码</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="215"/>
        <source>连接</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="228"/>
        <source>断开连接</source>
        <translation>断开连接</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="241"/>
        <source>远程设置</source>
        <translation>远程设置</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="254"/>
        <source>设备搜索</source>
        <translation>设备搜索</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="280"/>
        <source>开启解码</source>
        <translation>开启解码</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="293"/>
        <source>关闭解码</source>
        <translation>关闭解码</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="306"/>
        <source>开启预览</source>
        <translation>开启预览</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="319"/>
        <source>关闭预览</source>
        <translation>关闭预览</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="332"/>
        <source>抓图</source>
        <translation>抓图</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="345"/>
        <source>开启录像</source>
        <translation>开启录像</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="358"/>
        <source>加速播放</source>
        <translation>加速播放</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="371"/>
        <source>开启码流</source>
        <translation>开启码流</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="384"/>
        <source>停止录像</source>
        <translation>开启码流</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="397"/>
        <source>开启音频</source>
        <translation>开启音频</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="410"/>
        <source>关闭音频</source>
        <translation>关闭音频</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="423"/>
        <source>录像检索</source>
        <translation>录像检索</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="436"/>
        <source>减速播放</source>
        <translation>减速播放</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="449"/>
        <source>正常速度</source>
        <translation>正常速度</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="462"/>
        <source>暂停回放</source>
        <translation>暂停回放</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="475"/>
        <source>下载录像</source>
        <translation>下载录像</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="488"/>
        <source>停止码流</source>
        <translation>停止码流</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="501"/>
        <source>开始对讲</source>
        <translation>开始对讲</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="514"/>
        <source>停止对讲</source>
        <translation>停止对讲</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="527"/>
        <source>一键重设IP</source>
        <translation>一键重设IP</translation>
    </message>
</context>
<context>
    <name>remotecfgdlg</name>
    <message>
        <location filename="remotecfgdlg.ui" line="14"/>
        <source>远程设置</source>
        <translation>远程设置</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="42"/>
        <source>用户名</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="55"/>
        <source>权限</source>
        <translation>权限</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="68"/>
        <source>说明</source>
        <translation>说明</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="81"/>
        <source>密码</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="134"/>
        <source>添加</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="147"/>
        <source>删除</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="160"/>
        <source>修改</source>
        <translation>修改</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="173"/>
        <source>刷新</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="186"/>
        <source>确定</source>
        <translation>确定</translation>
    </message>
</context>
</TS>
