﻿
#pragma once

#include "event.h"

namespace Ui
{
    class finddevicedlg;
}

class finddevicedlg : public QDialog
{
Q_OBJECT

public:
    explicit finddevicedlg(bool bByJvnSDK, QWidget *parent = 0);
    ~finddevicedlg();

private:
	virtual void customEvent(QEvent *event);

private slots:
	void OnReflush();
	void OnSetIP();

private:
    Ui::finddevicedlg *ui;
	QStandardItemModel *m_pModel;
	bool m_bByJvnSDK;
};
