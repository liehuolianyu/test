﻿
#pragma once

#include "event.h"
#include "jcsdk.h"

namespace Ui
{
    class remotecfgdlg;
}

class remotecfgdlg : public QDialog
{
Q_OBJECT

public:
    explicit remotecfgdlg(int nLinkID, QWidget *parent = 0);
    ~remotecfgdlg();

public:

private slots:
	void OnAddUser();
	void OnDeleteUser();
	void OnModifyUser();
	void OnReflush();
	void OnOK();
	void OnItemClicked(const QModelIndex& index);

private:
    Ui::remotecfgdlg *ui;
	QStandardItemModel *m_pModel;

	const int m_nLinkID;
};
