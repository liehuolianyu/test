﻿
#pragma once

#include "qglobal.h"
#if QT_VERSION > QT_VERSION_CHECK(5, 0, 0)
#  include "QApplication"
#  include "QDialog"
#  include "QMessageBox"
#  include "QStandardItemModel"
#  include "QTranslator"
#else
#  include "QtGui/QApplication"
#  include "QtGui/QDialog"
#  include "QtGui/QMessageBox"
#  include "QtGui/QStandardItemModel"
#  include "QtCore/QTranslator"
#endif
#include "QtCore/QEvent"

extern QApplication* g_pMainApp;

class GetRecFileListEvent : public QEvent
{
public:
    GetRecFileListEvent(bool bOK);
    virtual ~GetRecFileListEvent();

public:
    bool IsOK() const;

    static QEvent::Type GetEventType();

private:
    bool m_bOK;
};

class ResetStreamEvent : public QEvent
{
public:
    ResetStreamEvent();
    virtual ~ResetStreamEvent();

public:
    static QEvent::Type GetEventType();
};

class LogEvent : public QEvent
{
public:
    LogEvent(const char* szLog);
    virtual ~LogEvent();

public:
	const char* GetLog() const;

    static QEvent::Type GetEventType();

private:
	std::string m_strLog;
};

class ReflushDevListEvent : public QEvent
{
public:
    ReflushDevListEvent();
    virtual ~ReflushDevListEvent();

public:
    static QEvent::Type GetEventType();
};
