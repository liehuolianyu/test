﻿
#include "remotecfgdlg.h"
#include "ui_remotecfgdlg.h"
#include "jcsdk.h"
#include "jgrpc.h"

remotecfgdlg::remotecfgdlg(int nLinkID, QWidget *parent)
	: QDialog(parent), ui(new Ui::remotecfgdlg), m_nLinkID(nLinkID)
{
	ui->setupUi(this);

	m_pModel = new QStandardItemModel();
	m_pModel->setColumnCount(3);
	m_pModel->setHeaderData(0, Qt::Horizontal, QString::fromLocal8Bit("用户名"));
	m_pModel->setHeaderData(1, Qt::Horizontal, QString::fromLocal8Bit("权限"));
	m_pModel->setHeaderData(2, Qt::Horizontal, QString::fromLocal8Bit("说明"));
	ui->tvUserInfo->setModel(m_pModel);
	ui->tvUserInfo->setColumnWidth(0, 150);
	ui->tvUserInfo->setColumnWidth(1, 150);
	ui->tvUserInfo->setColumnWidth(2, 150);

	ui->cbRight->addItem("admin");
	ui->cbRight->addItem("operator");
	ui->cbRight->addItem("user");
	ui->cbRight->addItem("anonymous");
	ui->cbRight->addItem("extended");

	QObject::connect(ui->btnAdd, SIGNAL(clicked()), this, SLOT(OnAddUser()));
	QObject::connect(ui->btnDelete, SIGNAL(clicked()), this, SLOT(OnDeleteUser()));
	QObject::connect(ui->btnModify, SIGNAL(clicked()), this, SLOT(OnModifyUser()));
	QObject::connect(ui->btnReflush, SIGNAL(clicked()), this, SLOT(OnReflush()));
	QObject::connect(ui->btnOK, SIGNAL(clicked()), this, SLOT(OnOK()));
	QObject::connect((QAbstractItemView*)ui->tvUserInfo, SIGNAL(clicked(const QModelIndex&)), this, SLOT(OnItemClicked(const QModelIndex&)));
}

remotecfgdlg::~remotecfgdlg()
{
}

void remotecfgdlg::OnAddUser()
{
	std::string strUsername = (const char*)ui->edtUser->text().toUtf8();
	std::string strPassword = (const char*)ui->edtPwd->text().toUtf8();
	std::string strDesc = (const char*)ui->edtInfo->text().toUtf8();
	std::string strLevel;
	switch(ui->cbRight->currentIndex())
	{
	case 0:
		strLevel = "admin";
		break;

	case 1:
		strLevel = "operator";
		break;

	case 2:
		strLevel = "user";
		break;

	case 3:
		strLevel = "anonymous";
		break;

	case 4:
		strLevel = "extended";
		break;
	}

	PARAM_REQ_sdk_account_add_user req;
	PARAM_RESP_sdk_account_add_user resq;
	req.name = (char*)strUsername.c_str();
	req.passwd = (char*)strPassword.c_str();
	req.level = (char*)strLevel.c_str();
	req.description = (char*)strDesc.c_str();

	QMessageBox dlg;
	if(JCSDK_GRPC_account_add_user(m_nLinkID, &req, &resq))
	{
		dlg.setText(QString::fromLocal8Bit("添加用户成功！"));
	}
	else
	{
		dlg.setText(QString::fromLocal8Bit("添加用户失败！"));
	}
	dlg.exec();
}

void remotecfgdlg::OnDeleteUser()
{
	int nIndex = ui->tvUserInfo->currentIndex().row();
	if(nIndex < 0)
	{
		return;
	}
	std::string strUsername = (const char*)m_pModel->item(nIndex, 0)->text().toUtf8();

	PARAM_REQ_sdk_account_del_user req;
	PARAM_RESP_sdk_account_del_user resq;
	req.name = (char*)strUsername.c_str();
	QMessageBox dlg;
	if(JCSDK_GRPC_account_del_user(m_nLinkID, &req, &resq))
	{
		dlg.setText(QString::fromLocal8Bit("删除用户成功！"));
	}
	else
	{
		dlg.setText(QString::fromLocal8Bit("删除用户失败！"));
	}
	dlg.exec();
}

void remotecfgdlg::OnModifyUser()
{
	std::string strUsername = (const char*)ui->edtUser->text().toUtf8();
	std::string strPassword = (const char*)ui->edtPwd->text().toUtf8();
	std::string strDesc = (const char*)ui->edtInfo->text().toUtf8();
	std::string strLevel;
	switch(ui->cbRight->currentIndex())
	{
	case 0:
		strLevel = "admin";
		break;

	case 1:
		strLevel = "operator";
		break;

	case 2:
		strLevel = "user";
		break;

	case 3:
		strLevel = "anonymous";
		break;

	case 4:
		strLevel = "extended";
		break;
	}

	PARAM_REQ_sdk_account_modify_user req;
	PARAM_RESP_sdk_account_modify_user resq;
	req.name = (char*)strUsername.c_str();
	req.passwd = (char*)strPassword.c_str();
	req.level = (char*)strLevel.c_str();
	req.description = (char*)strDesc.c_str();

	QMessageBox dlg;
	if(JCSDK_GRPC_account_modify_user(m_nLinkID, &req, &resq))
	{
		dlg.setText(QString::fromLocal8Bit("修改用户成功！"));
	}
	else
	{
		dlg.setText(QString::fromLocal8Bit("修改用户失败！"));
	}
	dlg.exec();
}

void remotecfgdlg::OnReflush()
{
	m_pModel->removeRows(0, m_pModel->rowCount());

	PARAM_REQ_sdk_account_get_users req;
	PARAM_RESP_sdk_account_get_users resp;
	if(JCSDK_GRPC_account_get_users(m_nLinkID, &req, &resp))
	{
		for(int i = 0; i < resp.users_cnt; ++i)
		{
			m_pModel->setItem(i, 0, new QStandardItem(QString::fromUtf8(resp.users[i].name)));
			m_pModel->setItem(i, 1, new QStandardItem(QString::fromUtf8(resp.users[i].level)));
			m_pModel->setItem(i, 2, new QStandardItem(QString::fromUtf8(resp.users[i].description)));
		}
	}
	else
	{
		QMessageBox dlg;(QString::fromLocal8Bit("刷新列表失败！"));
		dlg.exec();
	}
}

void remotecfgdlg::OnOK()
{
	close();
}

void remotecfgdlg::OnItemClicked(const QModelIndex& index)
{
	int nIndex = index.row();
	QStandardItem* pItem = m_pModel->item(nIndex, 0);
	if(pItem)
	{
		ui->edtUser->setText(pItem->text());
		ui->edtPwd->setText("******");
	}
	else
	{
		ui->edtUser->setText("");
		ui->edtPwd->setText("");
	}
	pItem = m_pModel->item(nIndex, 2);
	if(pItem)
	{
		ui->edtInfo->setText(pItem->text());
	}
	else
	{
		ui->edtInfo->setText("");
	}
	pItem = m_pModel->item(nIndex, 1);
	if(pItem)
	{
		int nIndex = 0;
		std::string strLevel = (const char*)pItem->text().toLocal8Bit();
		if(strLevel == "admin")
		{
			nIndex = 0;
		}
		else if(strLevel == "operator")
		{
			nIndex = 1;
		}
		else if(strLevel == "user")
		{
			nIndex = 2;
		}
		else if(strLevel == "anonymous")
		{
			nIndex = 3;
		}
		else if(strLevel == "extended")
		{
			nIndex = 4;
		}
		ui->cbRight->setCurrentIndex(nIndex);
	}
	else
	{
		ui->cbRight->setCurrentIndex(0);
	}
}
