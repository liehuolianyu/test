﻿
#include "mainwnd.h"
#include "ui_mainwnd.h"
#include "event.h"
#include "remotecfgdlg.h"
#include "finddevicedlg.h"
#include <cassert>
#include <ctime>
#include <string>
#ifndef LINUX
#  include "JTalk.h"
#endif

mainwnd *g_pMainWnd = NULL;
std::vector<JCRecFileInfo> g_RecFileInfoList;

char g_szRecFilename[] = "Video.mp4";
bool s_bDownload = false;

void funJCEventCallback(JCLink_t nLinkID, JCEventType etType, DWORD_PTR pData1, DWORD_PTR pData2, LPVOID pUserData)
{
    std::string strMsg;

    switch(etType)
    {
    case JCET_GetFileListOK://获取远程录像成功
        {
            g_RecFileInfoList.clear();
            PJCRecFileInfo pInfos = (PJCRecFileInfo)pData1;
            int nCount = (int)pData2;
            for(int i = 0; i < nCount; ++i)
            {
                g_RecFileInfoList.push_back(pInfos[i]);
            }
        }
        case JCET_GetFileListError://获取远程录像失败
        {
            g_pMainApp->postEvent(g_pMainWnd, new GetRecFileListEvent(etType == JCET_GetFileListOK));
        }
        return;
        break;

    case JCET_StreamReset://码流重置信号
        {
#ifndef LINUX
            JCSDK_EnableDecoder(nLinkID, FALSE);
#endif
            g_pMainApp->postEvent(g_pMainWnd, new ResetStreamEvent());
        }
        return;
        break;

    default:
        break;
    }

    switch(etType)
    {
    case JCET_ConnectOK://连接成功
        strMsg = "连接%d连接成功(%s)";
        break;

    case JCET_UserAccessError: //用户验证失败
        strMsg = "连接%d连接失败，用户验证失败";
        break;

    case JCET_NoChannel://主控通道未开启
        strMsg = "连接%d连接失败，主控通道未开启";
        break;

    case JCET_ConTypeError://连接类型错误
        strMsg = "连接%d连接失败，连接类型错误";
        break;

    case JCET_ConCountLimit://超过主控连接最大数
        strMsg = "连接%d连接失败，超过主控连接最大数";
        break;

    case JCET_ConTimeout://连接超时
        strMsg = "连接%d连接失败，连接超时";
        break;

    case JCET_DisconOK://断开连接成功
        strMsg = "连接%d断开连接成功";
        break;

    case JCET_ConAbout://连接异常断开
        strMsg = "连接%d连接异常断开";
        break;

    case JCET_ServiceStop://主控断开连接
        strMsg = "连接%d主控断开连接";
        break;

    default:
        return;
        break;
    }

	char acBuffer[64];
    std::string strMsg2;
    if(pData1 != NULL)
    {
        strMsg2 = (char*)pData1;
    }
    sprintf(acBuffer, strMsg.c_str(), nLinkID, strMsg2.c_str());
	g_pMainApp->postEvent(g_pMainWnd, new LogEvent(acBuffer));
}

void funJCDataCallback(JCLink_t nLinkID, PJCStreamFrame pFrame, LPVOID pUserData)
{
    //char acBuffer[32];
    //sprintf(acBuffer, "Type:%d\n", pFrame->sType);
    //OutputDebugStringA(acBuffer);
}

bool g_bDownloading = false;
void funJCDownloadDataCallback(JCLink_t nLinkID, JCDownloadEventType etType, DWORD dwProgress, DWORD dwFileSize, LPVOID pUserData)
{
	std::string strMsg;
 
    switch(etType)
    {
    case JCDET_DownloadData://录像下载数据
        if(!g_bDownloading)
        {
            g_bDownloading = true;
            strMsg = "连接%d开始下载录像";
        }
        else
        {
            return;
        }
        break;

    case JCDET_DownloadEnd://录像下载完成
        strMsg = "连接%d录像下载完成";
        break;

    case JCDET_DownloadStop://录像下载停止
        strMsg = "连接%d录像下载停止";
        break;

    case JCDET_DownloadError://远程下载失败
        strMsg = "连接%d远程下载失败";
        break;

    case JCDET_DownloadTimeout://远程下载超时
        strMsg = "连接%d远程下载超时";
        break;

    default:
        return;
        break;
    }

	g_pMainApp->postEvent(g_pMainWnd, new LogEvent(strMsg.c_str()));
}

void funJCTalkCallback(JCLink_t nLinkID, JCTalkEventType etType, JCCodecID cdCodec, PUCHAR pData, int nSize, LPVOID pUserData)
{
	switch(etType)
	{
	case JCTET_Accepted: //对方接受语音对讲
		{
#ifndef LINUX
			DWORD dwCodec = 0;
			switch(cdCodec)
			{
			case JCCID_G729A_8k16b://PC板卡类产品用
				dwCodec = JVT_CODECTYPE_g729a_8k16b;
				break;

			case JCCID_PCM_8k8b://旧设备使用，新设备已弃用
				dwCodec = JVT_CODECTYPE_pcm_8k8b;
				break;

			case JCCID_G711A_8k16b://嵌入式设备(IPC/DVR/NVR)使用
				dwCodec = JVT_CODECTYPE_g711a_8k16b;
				break;

			case JCCID_G711U_8k16b://嵌入式设备(IPC/DVR/NVR)使用
				dwCodec = JVT_CODECTYPE_g711u_8k16b;
				break;

			default:
				break;
			}
			IniTalk(dwCodec);
#endif
			g_pMainApp->postEvent(g_pMainWnd, new LogEvent("语音对讲开始"));
		}
		break;

	case JCTET_Data://语音对讲数据
		{
#ifndef LINUX
			SendVoliceDataIn((char*)pData, nSize);
#endif
		}
		break;

	case JCTET_Stoped://语音对讲结束
		{
#ifndef LINUX
			EndTalk();
#endif
			g_pMainApp->postEvent(g_pMainWnd, new LogEvent("语音对讲停止"));
		}
		break;

	default:
		break;
	}
}

void funSendDataCallback(char *pBuffer, int nLen)
{
	JCSDK_SendTalkData(g_pMainWnd->GetLinkID(), (PUCHAR)pBuffer, nLen);
}

bool g_bGetPicture = false;
char g_szPictureFilename[] = "pic.bmp";

inline UCHAR Clip(int num)
{
    return (UCHAR)(((num) > 255)?255:(((num) < 0)?0:(num)));
}

inline UCHAR GetR(int y, int u, int v)
{
    return Clip((298 * (y - 16) + 409 * (v - 128) + 128) >> 8);
}

inline UCHAR GetG(int y, int u, int v)
{
    return Clip((298 * (y - 16) - 100 * (u - 128) - 208 * (v - 128) + 128) >> 8);
}

inline UCHAR GetB(int y, int u, int v)
{
    return Clip((298 * (y - 16) + 516 * (u - 128) + 128) >> 8);
}

void yv12_to_rgb32(PUCHAR pDest, DWORD dwDestPitch, PUCHAR pSrcY, PUCHAR pSrcU, PUCHAR pSrcV,
    DWORD dwSrcYPitch, DWORD dwSrcUPitch, DWORD dwSrcVPitch, DWORD dwWidth, DWORD dwHeight)
{
    pDest += 4 * dwWidth * (dwHeight - 1);

//    int nYCount = dwHeight / 2;
    int nXCount = dwWidth / 2;
    for(DWORD y = 0; y < dwHeight; ++y)
    {
        PUCHAR pDestLine = pDest;
        PUCHAR pSrcYLine = pSrcY;
        PUCHAR pSrcULine = pSrcU;
        PUCHAR pSrcVLine = pSrcV;

        for(int x = 0; x < nXCount; ++x)
        {
            *(pDestLine++) = GetB(*pSrcYLine, *pSrcULine, *pSrcVLine);
            *(pDestLine++) = GetG(*pSrcYLine, *pSrcULine, *pSrcVLine);
            *(pDestLine++) = GetR(*pSrcYLine, *pSrcULine, *pSrcVLine);
            *(pDestLine++) = 255;

            ++pSrcYLine;

            *(pDestLine++) = GetB(*pSrcYLine, *pSrcULine, *pSrcVLine);
            *(pDestLine++) = GetG(*pSrcYLine, *pSrcULine, *pSrcVLine);
            *(pDestLine++) = GetR(*pSrcYLine, *pSrcULine, *pSrcVLine);
            *(pDestLine++) = 255;

            ++pSrcYLine;
            ++pSrcULine;
            ++pSrcVLine;
        }

        pDest -= dwDestPitch;
        pSrcY += dwSrcYPitch;
        if(y % 2 == 1)
        {
            pSrcU += dwSrcUPitch;
            pSrcV += dwSrcVPitch;
        }
    }
}

void funJCRawDataCallback(JCLink_t nLinkID, PJCRawFrame pFrame, LPVOID pUserData)
{
}

extern void funLanSearchCallback(PJCLanDeviceInfo pDevice);

mainwnd::mainwnd(QWidget *parent)
        : QDialog(parent), ui(new Ui::mainwnd)
{
    ui->setupUi(this);

    QObject::connect(ui->btnConnect, SIGNAL(clicked()), this, SLOT(OnConnect()));
    QObject::connect(ui->btnDisconnect, SIGNAL(clicked()), this, SLOT(OnDisconnect()));
    QObject::connect(ui->btnRemoteCfg, SIGNAL(clicked()), this, SLOT(OnRemoteCfg()));
    QObject::connect(ui->btnDevSearch, SIGNAL(clicked()), this, SLOT(OnDevSearch()));

    QObject::connect(ui->btnStartDecode, SIGNAL(clicked()), this, SLOT(OnStartDecode()));
    QObject::connect(ui->btnStopDecode, SIGNAL(clicked()), this, SLOT(OnStopDecode()));
    QObject::connect(ui->btnStartPreview, SIGNAL(clicked()), this, SLOT(OnStartPreview()));
    QObject::connect(ui->btnStopPreview, SIGNAL(clicked()), this, SLOT(OnStopPreview()));
    QObject::connect(ui->btnGetPicture, SIGNAL(clicked()), this, SLOT(OnGetPicture()));

	QObject::connect(ui->btnStartRec, SIGNAL(clicked()), this, SLOT(OnStartRec()));
	QObject::connect(ui->btnStopRec, SIGNAL(clicked()), this, SLOT(OnStopRec()));
	QObject::connect(ui->btnStartAudio, SIGNAL(clicked()), this, SLOT(OnStartAudio()));
	QObject::connect(ui->btnStopAudio, SIGNAL(clicked()), this, SLOT(OnStopAudio()));
	QObject::connect(ui->btnGetFileList, SIGNAL(clicked()), this, SLOT(OnGetRecFileList()));

	QObject::connect(ui->btnSpeedUp, SIGNAL(clicked()), this, SLOT(OnSpeedUp()));
	QObject::connect(ui->btnSpeedDown, SIGNAL(clicked()), this, SLOT(OnSpeedDown()));
	QObject::connect(ui->btnSpeedNromal, SIGNAL(clicked()), this, SLOT(OnSpeedNormal()));
	QObject::connect(ui->btnPause, SIGNAL(clicked()), this, SLOT(OnSpeedPause()));
	QObject::connect(ui->btnDownload, SIGNAL(clicked()), this, SLOT(OnDownload()));

	QObject::connect(ui->btnStartStream, SIGNAL(clicked()), this, SLOT(OnEnableStream()));
	QObject::connect(ui->btnStopStream, SIGNAL(clicked()), this, SLOT(OnDisableStream()));
	QObject::connect(ui->btnStartTalk, SIGNAL(clicked()), this, SLOT(OnStartTalk()));
	QObject::connect(ui->btnStopTalk, SIGNAL(clicked()), this, SLOT(OnStopTalk()));
	QObject::connect(ui->btnOneKeyIP, SIGNAL(clicked()), this, SLOT(OnOneKeyIP()));

    g_pMainWnd = this;
    m_nLinkID = JCSDK_INVALID_LINKVALUE;
    m_bPreview = false;
    m_bDecoding = false;
    m_bPreviewing = false;

    ui->edtYSTNum->setText("a365");
    ui->edtIP->setText("172.16.26.251");
    ui->edtPort->setText("9101");
    ui->edtChannel->setText("1");
    ui->edtUser->setText("admin");
    ui->edtPwd->setText("123");
}

mainwnd::~mainwnd()
{
    delete ui;
}

bool mainwnd::Init()
{
    if(!JCSDK_InitSDK(-1, NULL))
    {
        return false;
    }

    JCSDK_RegisterCallback(funJCEventCallback, funJCDataCallback, funJCDownloadDataCallback, funJCRawDataCallback, funLanSearchCallback);

    return true;
}

void mainwnd::Release()
{
    JCSDK_ReleaseSDK();
}

void mainwnd::AddLogItem(const char* szLog)
{
#ifdef LINUX
    ui->lstLogs->addItem(new QListWidgetItem(QString::fromUtf8(szLog)));
#else
	ui->lstLogs->addItem(new QListWidgetItem(QString::fromLocal8Bit(szLog)));
#endif
    ui->lstLogs->setCurrentRow(ui->lstLogs->count() - 1);
}

void mainwnd::moveEvent(QMoveEvent* event)
{
#ifndef LINUX
	if(m_bPreview)
	{
		QRect qrt = ui->wndShowWnd->rect();
		RECT rt = {qrt.left(), qrt.top(), qrt.right(), qrt.bottom()};
		ClientToScreen((HWND)ui->wndShowWnd->winId(), (LPPOINT)&rt);
		ClientToScreen((HWND)ui->wndShowWnd->winId(), &((LPPOINT)&rt)[1]);
		JCSDK_SetVideoPreview(m_nLinkID, (HWND)ui->wndShowWnd->winId(), &rt);
	}
#endif
	QDialog::moveEvent(event);
}

void mainwnd::customEvent(QEvent *event)
{
    if(event->type() == GetRecFileListEvent::GetEventType())
    {
        GetRecFileListEvent* pEvent = dynamic_cast<GetRecFileListEvent*>(event);
        assert(pEvent != NULL);

        std::string strMsg;
        if(pEvent->IsOK())
        {
            ui->lstRecFiles->clear();
            int nCount = g_RecFileInfoList.size();
            for(int i = 0; i < nCount; ++i)
            {
                ui->lstRecFiles->addItem(new QListWidgetItem(QString::fromLocal8Bit(g_RecFileInfoList[i].szPathName)));
            }

            if(nCount == 0)
            {
                strMsg = "连接%d无录像文件";
            }
            else
            {
                strMsg = "连接%d获取录像列表成功";
            }
        }
        else
        {
            strMsg = "连接%d获取录像列表失败";
        }

        char acBuffer[64];
        sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
        AddLogItem(acBuffer);
    }
    else if(event->type() == ResetStreamEvent::GetEventType())
    {
//        ResetStreamEvent* pEvent = dynamic_cast<ResetStreamEvent*>(event);
 //       assert(pEvent != NULL);
    }
	else if(event->type() == LogEvent::GetEventType())
	{
		LogEvent* pEvent = dynamic_cast<LogEvent*>(event);
        assert(pEvent != NULL);
		AddLogItem(pEvent->GetLog());
	}
}

void mainwnd::OnConnect()
{
    if(m_nLinkID != JCSDK_INVALID_LINKVALUE)
    {
        JCSDK_Disconnect(m_nLinkID);
    }
	
	std::string strCloudSEE = (const char*)ui->edtYSTNum->text().toLocal8Bit();
    std::string strIP = (const char*)ui->edtIP->text().toLocal8Bit();
    std::string strUser = (const char*)ui->edtUser->text().toLocal8Bit();
    std::string strPwd = (const char*)ui->edtPwd->text().toLocal8Bit();
    int nChannel = ui->edtChannel->text().toInt();
    if(nChannel <= 0)
    {
        QMessageBox dlg;
        dlg.setText(QString::fromStdWString(L"通道号错误！"));
        dlg.exec();
        return;
    }
    int nPort = ui->edtPort->text().toInt();
    if(nPort <= 0)
    {
        QMessageBox dlg;
        dlg.setText(QString::fromStdWString(L"端口错误！"));
        dlg.exec();
        return;
    }
	
    if(ui->rbYSTIn->isChecked())
    {
        m_nLinkID = JCSDK_Connect((char*)strCloudSEE.c_str(), 0, nChannel, (char*)strUser.c_str(), (char*)strPwd.c_str(), TRUE, NULL);
    }
    else
    {
        m_nLinkID = JCSDK_Connect((char*)strIP.c_str(), nPort, nChannel, (char*)strUser.c_str(), (char*)strPwd.c_str(), FALSE, NULL);
    }

    if(m_nLinkID == -1)
    {
        AddLogItem("调用连接函数失败！");
    }
    else
    {
        char acBuffer[64];
        sprintf(acBuffer, "连接%d正在连接...", m_nLinkID);
        AddLogItem(acBuffer);
    }
}

void mainwnd::OnDisconnect()
{
    JCSDK_Disconnect(m_nLinkID);
    m_bDecoding = false;
    m_bPreviewing = false;
}

void mainwnd::OnRemoteCfg()
{
    if(JCSDK_GRPC_Begin(m_nLinkID))
    {
        remotecfgdlg dlg(m_nLinkID);
        dlg.exec();
        JCSDK_GRPC_End(m_nLinkID);
    }
    else
    {
        QMessageBox dlg;
        dlg.setText(QString::fromStdWString(L"远程设置失败!"));
        dlg.exec();
    }
}

void mainwnd::OnDevSearch()
{
    finddevicedlg dlg(true);
    dlg.exec();
}

void mainwnd::OnStartDecode()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	std::string strMsg;
	if(JCSDK_EnableDecoder(m_nLinkID, TRUE))
	{
		strMsg = "连接%d开启解码成功";
		m_bDecoding = true;
	}
	else
	{
		strMsg = "连接%d开启解码失败";
		m_bDecoding = false;
		m_bPreviewing = false;
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(),  m_nLinkID);
	AddLogItem(acBuffer);
#endif
}

void mainwnd::OnStopDecode()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	std::string strMsg;
	if(JCSDK_EnableDecoder(m_nLinkID, FALSE))
	{
		strMsg = "连接%d关闭解码器成功";
	}
	else
	{
		strMsg = "连接%d关闭解码器失败";
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(),  m_nLinkID);
	AddLogItem(acBuffer);

	m_bDecoding = false;
	m_bPreviewing = false;
#endif
}

void mainwnd::OnStartPreview()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	QRect qrt = ui->wndShowWnd->rect();
	RECT rt = {qrt.left(), qrt.top(), qrt.right(), qrt.bottom()};
	ClientToScreen((HWND)ui->wndShowWnd->winId(), (LPPOINT)&rt);
	ClientToScreen((HWND)ui->wndShowWnd->winId(), &((LPPOINT)&rt)[1]);
	//m_stcShowRect.GetClientRect(&rtRect);
	//m_stcShowRect.ClientToScreen(&rtRect);

	std::string strMsg;
	if(JCSDK_SetVideoPreview(m_nLinkID, (HWND)ui->wndShowWnd->winId(), &rt))
	{
		strMsg = "连接%d开启预览成功";
		m_bPreview = true;
		m_bPreviewing = true;
	}
	else
	{
		strMsg = "连接%d关闭预览成功";
		m_bPreview = false;
		m_bPreviewing = false;
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(),  m_nLinkID);
	AddLogItem(acBuffer);
#endif
}

void mainwnd::OnStopPreview()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	std::string strMsg;
	if(JCSDK_SetVideoPreview(m_nLinkID, NULL, NULL))
	{
		strMsg = "连接%d关闭预览成功";
	}
	else
	{
		strMsg = "连接%d关闭预览失败";
	}
	m_bPreview = false;
	m_bPreviewing = false;

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(),  m_nLinkID);
	AddLogItem(acBuffer);
#endif
}

void mainwnd::OnGetPicture()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	std::string strMsg;
	if(JCSDK_SaveBitmap(m_nLinkID, g_szPictureFilename))
	{
		strMsg = "连接%d截图成功，保存到%s";
	}
	else
	{
		strMsg = "连接%d截图失败";
	}
	m_bPreview = false;
	m_bPreviewing = false;

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID, g_szPictureFilename);
	AddLogItem(acBuffer);
#endif
}

void mainwnd::OnStartRec()
{
    std::string szFilename;
    JCStreamInfo info;
    if(JCSDK_GetStreamInfo(m_nLinkID, &info))
    {
        switch(info.eRecFileType)
        {
        case JCRT_SV4:
            szFilename = "007.sv4";
            break;

        case JCRT_SV5:
            szFilename = "007.sv5";
            break;

        case JCRT_SV6:
            szFilename = "007.sv6";
            break;

        case JCRT_MP4:
		case JCRT_JVFS:
            szFilename = "007.mp4";
            break;

        default:
            break;
        }
    }

    std::string strMsg;
    if(szFilename.empty())
    {
        strMsg = "连接%d开启录像失败";
    }
    else if(JCSDK_StartRec(m_nLinkID, (char*)szFilename.c_str()))
    {
        strMsg = "连接%d开启录像成功";
    }
    else
    {
        strMsg = "连接%d开启录像失败";
    }

    char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
}

void mainwnd::OnStopRec()
{
    std::string strMsg;
    if(JCSDK_StopRec(m_nLinkID))
    {
        strMsg = "连接%d停止录像成功";
    }
    else
    {
        strMsg = "连接%d停止录像失败";
    }

    char acBuffer[64];
    sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
    AddLogItem(acBuffer);
}

void mainwnd::OnStartAudio()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	std::string strMsg;
	if(JCSDK_SetAudioPreview(m_nLinkID, (HWND)ui->wndShowWnd->winId()))
	{
		strMsg = "连接%d开启音频预览成功";
	}
	else
	{
		strMsg = "连接%d开启音频预览失败";
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
#endif
}

void mainwnd::OnStopAudio()
{
#ifdef LINUX
    QMessageBox dlg;
    dlg.setText(QString::fromStdWString(L"Linux下不支持该功能"));
    dlg.exec();
#else
	std::string strMsg;
	if(JCSDK_SetAudioPreview(m_nLinkID, NULL))
	{
		strMsg = "连接%d关闭音频预览成功";
	}
	else
	{
		strMsg = "连接%d关闭音频预览失败";
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
#endif
}

void mainwnd::OnGetRecFileList()
{
    std::string strMsg;
    JCDateBlock data;
    time_t t;
    time(&t);
    tm *d = localtime(&t);
    data.nBeginYear = data.nEndYear = d->tm_year + 1900;
    data.nBeginMonth = data.nEndMonth = d->tm_mon + 1;
    data.nBeginDay = data.nEndDay = d->tm_mday;

    if(JCSDK_GetRemoteRecFileList(m_nLinkID, &data))
    {
        return;
    }
    else
    {
        strMsg = "连接%d获取录像文件列表失败";
    }

    char acBuffer[64];
    sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
    AddLogItem(acBuffer);
}

void mainwnd::OnSpeedUp()
{
    JCSDK_RemotePlayControl(m_nLinkID, JCRPC_SpeedUp, 0);
}

void mainwnd::OnSpeedDown()
{
    JCSDK_RemotePlayControl(m_nLinkID, JCRPC_SpeedDown, 0);
}

void mainwnd::OnSpeedNormal()
{
    JCSDK_RemotePlayControl(m_nLinkID, JCRPC_SpeedNormal, 0);
}

void mainwnd::OnSpeedPause()
{
    static bool s_bPause = false;
    if(s_bPause)
    {
        JCSDK_RemotePlayControl(m_nLinkID, JCRPC_Play, 0);
        ui->btnPause->setText(QString::fromStdWString(L"暂停"));
    }
    else
    {
        JCSDK_RemotePlayControl(m_nLinkID, JCRPC_Pause, 0);
        ui->btnPause->setText(QString::fromStdWString(L"播放"));
    }
    s_bPause = !s_bPause;
}

void mainwnd::OnDownload()
{
    if(s_bDownload)
    {
        if(g_bDownloading)
        {
            char acBuffer[64];
            sprintf(acBuffer, "连接%d下载结束", m_nLinkID);
            AddLogItem(acBuffer);
            g_bDownloading = false;
        }

        JCSDK_DownloadRemoteFile(m_nLinkID, -1, NULL);
        ui->btnDownload->setText(QString::fromStdWString(L"下载"));
    }
    else
    {
        g_bDownloading = false;
        int nIndex = ui->lstRecFiles->currentRow();
        JCSDK_DownloadRemoteFile(m_nLinkID, nIndex, g_szRecFilename);
        ui->btnDownload->setText(QString::fromStdWString(L"停止下载"));
    }
    s_bDownload = !s_bDownload;
}

void mainwnd::OnEnableStream()
{
	std::string strMsg;
	if(JCSDK_EnableVideoData(m_nLinkID, JTRUE))
	{
		strMsg = "连接%d开启音视频数据成功";
	}
	else
	{
		strMsg = "连接%d开启音视频数据失败";
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
}

void mainwnd::OnDisableStream()
{
	std::string strMsg;
	if(JCSDK_EnableVideoData(m_nLinkID, JFALSE))
	{
		strMsg = "连接%d关闭音视频数据成功";
	}
	else
	{
		strMsg = "连接%d关闭音视频数据失败";
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
}

void mainwnd::OnStartTalk()
{
	std::string strMsg;
	JCSDK_RegisterTalkCallback(funJCTalkCallback);
#ifndef LINUX
	JVA_RegisterCallBack(funSendDataCallback);
#endif
	if(JCSDK_StartTalk(m_nLinkID))
	{
		strMsg = "连接%d开启语音对讲成功";
	}
	else
	{
		strMsg = "连接%d开启语音对讲失败";
	}

	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
}

void mainwnd::OnStopTalk()
{
	std::string strMsg;
	if(JCSDK_StopTalk(m_nLinkID))
	{
		strMsg = "连接%d停止语音对讲成功";
	}
	else
	{
		strMsg = "连接%d停止语音对讲失败";
	}
#ifndef LINUX
	EndTalk();
#endif
	char acBuffer[64];
	sprintf(acBuffer, strMsg.c_str(), m_nLinkID);
	AddLogItem(acBuffer);
}

void mainwnd::OnOneKeyIP()
{
    finddevicedlg dlg(false);
    dlg.exec();
}
