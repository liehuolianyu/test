﻿
#include "finddevicedlg.h"
#include "jcsdk.h"
#include "ui_finddevicedlg.h"
#include "event.h"
#ifdef LINUX
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#endif

finddevicedlg* g_pFindDeviceWnd = NULL;
std::vector<JCLanDeviceInfo> g_DeviceInfosList;
std::vector<JCOKIPDeviceInfo> g_OKIPDeviceInfosList;


void funLanSearchCallback(PJCLanDeviceInfo pDevice)
{
	if(pDevice == NULL)
	{
		g_pMainApp->postEvent(g_pFindDeviceWnd, new ReflushDevListEvent());
	}
	else
	{
		bool bFind = false;
		for(size_t i = 0; i < g_DeviceInfosList.size(); ++i)
		{
			if(strcmp(pDevice->szIP, g_DeviceInfosList[i].szIP) == 0)
			{
				bFind = true;
				break;
			}
		}
		if(!bFind)
		{
			g_DeviceInfosList.push_back(*pDevice);
		}
	}
}

void funOKIPCallback(PJCOKIPDeviceInfo pDev)
{
	if(pDev == NULL)
	{
		g_pMainApp->postEvent(g_pFindDeviceWnd, new ReflushDevListEvent());
	}
	else
	{
		bool bFind = false;
		for(size_t i = 0; i < g_OKIPDeviceInfosList.size(); ++i)
		{
			if(strcmp(pDev->szYSTNum, g_OKIPDeviceInfosList[i].szYSTNum) == 0)
			{
				bFind = true;
				break;
			}
		}
		if(!bFind)
		{
			g_OKIPDeviceInfosList.push_back(*pDev);
		}
	}
}


finddevicedlg::finddevicedlg(bool bByJvnSDK, QWidget *parent) : QDialog(parent), ui(new Ui::finddevicedlg)
{
	ui->setupUi(this);

	g_pFindDeviceWnd = this;
	m_bByJvnSDK = bByJvnSDK;

	m_pModel = new QStandardItemModel();
	m_pModel->setColumnCount(6);
	m_pModel->setHeaderData(0, Qt::Horizontal, QString::fromLocal8Bit("云视通号"));
	m_pModel->setHeaderData(1, Qt::Horizontal, QString::fromLocal8Bit("IP"));
	m_pModel->setHeaderData(2, Qt::Horizontal, QString::fromLocal8Bit("端口"));
	m_pModel->setHeaderData(3, Qt::Horizontal, QString::fromLocal8Bit("设备类型"));
	m_pModel->setHeaderData(4, Qt::Horizontal, QString::fromLocal8Bit("通道数"));
	m_pModel->setHeaderData(5, Qt::Horizontal, QString::fromLocal8Bit("设备名"));
	ui->tvDevs->setModel(m_pModel);
	ui->tvDevs->setColumnWidth(0, 100);
	ui->tvDevs->setColumnWidth(1, 110);
	ui->tvDevs->setColumnWidth(2, 50);
	ui->tvDevs->setColumnWidth(3, 70);
	ui->tvDevs->setColumnWidth(4, 50);
	ui->tvDevs->setColumnWidth(5, 140);

	QObject::connect(ui->btnReflush, SIGNAL(clicked()), this, SLOT(OnReflush()));
	if(bByJvnSDK)
	{
		ui->btnSetIP->setVisible(false);
	}
	else
	{
		ui->btnSetIP->setDisabled(true);
		QObject::connect(ui->btnSetIP, SIGNAL(clicked()), this, SLOT(OnSetIP()));
		JCSDK_OKIP_StartService(funOKIPCallback);
	}
}

finddevicedlg::~finddevicedlg()
{
	if(!m_bByJvnSDK)
	{
		JCSDK_OKIP_StopService();
	}
}

void finddevicedlg::customEvent(QEvent *event)
{
	if(m_bByJvnSDK)
	{
		int count = g_DeviceInfosList.size();
		m_pModel->removeRows(0, m_pModel->rowCount());
		char acBuffer[64];
		for(int i = 0; i < count; ++i)
		{
			m_pModel->setItem(i, 0, new QStandardItem(QString::fromLocal8Bit(g_DeviceInfosList[i].szCloudSEE)));
			m_pModel->setItem(i, 1, new QStandardItem(QString::fromLocal8Bit(g_DeviceInfosList[i].szIP)));
			sprintf(acBuffer, "%d", g_DeviceInfosList[i].nPort);
			m_pModel->setItem(i, 2, new QStandardItem(QString::fromLocal8Bit(acBuffer)));
			std::string strType;
			switch(g_DeviceInfosList[i].nDeviceType)
			{
			case JCDT_Card:
				strType = "Card";
				break;

			case JCDT_DVR:
				strType = "DVR";
				break;

			case JCDT_IPC:
				strType = "IPC";
				break;

			case JCDT_NVR:
				strType = "NVR";
				break;

			default:
				strType = "Unknown";
				break;
			}
			m_pModel->setItem(i, 3, new QStandardItem(QString::fromLocal8Bit(strType.c_str())));
			sprintf(acBuffer, "%d", g_DeviceInfosList[i].nChannelNum);
			m_pModel->setItem(i, 4, new QStandardItem(QString::fromLocal8Bit(acBuffer)));
			m_pModel->setItem(i, 5, new QStandardItem(QString::fromLocal8Bit(g_DeviceInfosList[i].szDeviceName)));
		}

		ui->btnReflush->setDisabled(false);
	}
	else
	{
		int count = g_OKIPDeviceInfosList.size();
		m_pModel->removeRows(0, m_pModel->rowCount());
		char acBuffer[64];
		for(int i = 0; i < count; ++i)
		{
			m_pModel->setItem(i, 0, new QStandardItem(QString::fromLocal8Bit(g_OKIPDeviceInfosList[i].szYSTNum)));
			m_pModel->setItem(i, 1, new QStandardItem(QString::fromLocal8Bit(g_OKIPDeviceInfosList[i].szIP)));
			sprintf(acBuffer, "%d", g_OKIPDeviceInfosList[i].nPort);
			m_pModel->setItem(i, 2, new QStandardItem(QString::fromLocal8Bit(acBuffer)));
			std::string strType;
			switch(g_OKIPDeviceInfosList[i].dtType)
			{
			case JCDT_Card:
				strType = "Card";
				break;

			case JCDT_DVR:
				strType = "DVR";
				break;

			case JCDT_IPC:
				strType = "IPC";
				break;

			case JCDT_NVR:
				strType = "NVR";
				break;

			default:
				strType = "Unknown";
				break;
			}
			m_pModel->setItem(i, 3, new QStandardItem(QString::fromLocal8Bit(strType.c_str())));
			sprintf(acBuffer, "%d", g_OKIPDeviceInfosList[i].nChannelNum);
			m_pModel->setItem(i, 4, new QStandardItem(QString::fromLocal8Bit(acBuffer)));
			m_pModel->setItem(i, 5, new QStandardItem(QString::fromLocal8Bit(g_OKIPDeviceInfosList[i].szName)));
		}

		ui->btnReflush->setDisabled(false);
		ui->btnSetIP->setDisabled(g_OKIPDeviceInfosList.empty());
	}
}

void finddevicedlg::OnReflush()
{
	g_DeviceInfosList.clear();
	g_OKIPDeviceInfosList.clear();

	if(m_bByJvnSDK)
	{
		if(JCSDK_LanSeartchDevice(JCDT_All, 2000))
		{
			ui->btnReflush->setDisabled(true);
		}
	}
	else
	{
		if(JCSDK_OKIP_FinDevs(1000))
		{
			ui->btnReflush->setDisabled(true);
			ui->btnSetIP->setDisabled(true);
		}
	}
}

void finddevicedlg::OnSetIP()
{
	int nIPBegin = 151;
	char acBuffer[32] = {0};
	for(size_t i = 0; i < g_OKIPDeviceInfosList.size(); ++i)
	{
		JCOKIPNetCfg cfg = {0};
		cfg.bDHCP = JFALSE;
		sprintf(acBuffer, "172.16.26.%d", nIPBegin + i);
		cfg.dwIP = inet_addr(acBuffer);
		cfg.dwNetMask = inet_addr("255.255.255.0");
		cfg.dwGateWay = inet_addr("172.16.26.1");
		cfg.dwDNS = inet_addr("8.8.8.8");
		char acUser[] = "abc";
		char acPwd[] = "123";
		JCSDK_OKIP_SetNetCfg(g_OKIPDeviceInfosList[i].szYSTNum, acUser, acPwd, &cfg);
	}
}
