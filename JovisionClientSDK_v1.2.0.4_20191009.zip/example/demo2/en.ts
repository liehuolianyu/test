<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>finddevicedlg</name>
    <message>
        <location filename="finddevicedlg.ui" line="14"/>
        <source>设备检索</source>
        <translation>Search</translation>
    </message>
    <message>
        <location filename="finddevicedlg.ui" line="26"/>
        <source>刷新</source>
        <translation>Reflash</translation>
    </message>
    <message>
        <location filename="finddevicedlg.ui" line="58"/>
        <source>重设IP</source>
        <translation>ResetIP</translation>
    </message>
</context>
<context>
    <name>mainwnd</name>
    <message>
        <location filename="mainwnd.ui" line="14"/>
        <source>Demo</source>
        <translation>Demo</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="60"/>
        <source>云视通</source>
        <translation>CloudSEE</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="96"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="122"/>
        <source>端口</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="146"/>
        <source>通道号</source>
        <translation>Channel</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="169"/>
        <source>用户名</source>
        <translation>User</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="182"/>
        <source>密码</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="215"/>
        <source>连接</source>
        <translation>Connect</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="228"/>
        <source>断开连接</source>
        <translation>Disconnect</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="241"/>
        <source>远程设置</source>
        <translation>RemoteCfg</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="254"/>
        <source>设备搜索</source>
        <translation>DevSearch</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="280"/>
        <source>开启解码</source>
        <translation>EnableDecoder</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="293"/>
        <source>关闭解码</source>
        <translation>DisableDecoder</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="306"/>
        <source>开启预览</source>
        <translation>EnablePreview</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="319"/>
        <source>关闭预览</source>
        <translation>DisablePreview</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="332"/>
        <source>抓图</source>
        <translation>GetPicture</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="345"/>
        <source>开启录像</source>
        <translation>StartRec</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="358"/>
        <source>加速播放</source>
        <translation>SpeedUp</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="371"/>
        <source>开启码流</source>
        <translation>EnableStream</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="384"/>
        <source>停止录像</source>
        <translation>StopRec</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="397"/>
        <source>开启音频</source>
        <translation>EnableAudio</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="410"/>
        <source>关闭音频</source>
        <translation>DisableAudio</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="423"/>
        <source>录像检索</source>
        <translation>GetRecFiles</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="436"/>
        <source>减速播放</source>
        <translation>SpeedDown</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="449"/>
        <source>正常速度</source>
        <translation>NormalSpeed</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="462"/>
        <source>暂停回放</source>
        <translation>PausePalyback</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="475"/>
        <source>下载录像</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="488"/>
        <source>停止码流</source>
        <translation>DisableStream</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="501"/>
        <source>开始对讲</source>
        <translation>StartTalk</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="514"/>
        <source>停止对讲</source>
        <translation>StopTalk</translation>
    </message>
    <message>
        <location filename="mainwnd.ui" line="527"/>
        <source>一键重设IP</source>
        <translation>OneKeyIP</translation>
    </message>
</context>
<context>
    <name>remotecfgdlg</name>
    <message>
        <location filename="remotecfgdlg.ui" line="14"/>
        <source>远程设置</source>
        <translation>Remote Config</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="42"/>
        <source>用户名</source>
        <translation>User</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="55"/>
        <source>权限</source>
        <translation>Right</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="68"/>
        <source>说明</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="81"/>
        <source>密码</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="134"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="147"/>
        <source>删除</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="160"/>
        <source>修改</source>
        <translation>Modify</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="173"/>
        <source>刷新</source>
        <translation>Reflash</translation>
    </message>
    <message>
        <location filename="remotecfgdlg.ui" line="186"/>
        <source>确定</source>
        <translation>OK</translation>
    </message>
</context>
</TS>
