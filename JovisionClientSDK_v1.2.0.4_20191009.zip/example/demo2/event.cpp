﻿
#include "event.h"

int g_nGetRecFileListEventType = QEvent::registerEventType(-1);
int g_nResetStreamEventType = QEvent::registerEventType(-1);
int g_nLogEventType = QEvent::registerEventType(-1);
int g_nReflushDevListEventType = QEvent::registerEventType(-1);

GetRecFileListEvent::GetRecFileListEvent(bool bOK) : QEvent(GetEventType()), m_bOK(bOK)
{
}

GetRecFileListEvent::~GetRecFileListEvent()
{
}

bool GetRecFileListEvent::IsOK() const
{
    return m_bOK;
}

QEvent::Type GetRecFileListEvent::GetEventType()
{
    return (Type)g_nGetRecFileListEventType;
}


ResetStreamEvent::ResetStreamEvent() : QEvent(GetEventType())
{
}

ResetStreamEvent::~ResetStreamEvent()
{
}

QEvent::Type ResetStreamEvent::GetEventType()
{
    return (Type)g_nResetStreamEventType;
}


LogEvent::LogEvent(const char* szLog) : QEvent(GetEventType()), m_strLog(szLog)
{
}

LogEvent::~LogEvent()
{
}

const char* LogEvent::GetLog() const
{
	return m_strLog.c_str();
}

QEvent::Type LogEvent::GetEventType()
{
	return (Type)g_nLogEventType;
}


ReflushDevListEvent::ReflushDevListEvent() : QEvent(GetEventType())
{
}

ReflushDevListEvent::~ReflushDevListEvent()
{
}

QEvent::Type ReflushDevListEvent::GetEventType()
{
    return (Type)g_nReflushDevListEventType;
}
