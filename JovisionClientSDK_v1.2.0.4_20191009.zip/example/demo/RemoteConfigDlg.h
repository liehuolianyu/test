#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CRemoteConfigDlg �Ի���

class CRemoteConfigDlg : public CDialog
{
	DECLARE_DYNAMIC(CRemoteConfigDlg)

public:
	CRemoteConfigDlg(int nLinkID, CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CRemoteConfigDlg();

// �Ի�������
	enum { IDD = IDD_REMOTECONFIGDLG };

private:
	int m_nLinkID;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CString m_strUserDesc;
	CString m_strUsername;
	CString m_strPassword;
	CListCtrl m_lstUserList;
	CComboBox m_cbUserLevel;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonGetusers();
	afx_msg void OnBnClickedButtonAdduser();
	afx_msg void OnBnClickedButtonDeleteuser();
	afx_msg void OnBnClickedButtonModifyuser();
	afx_msg void OnNMClickListUserlist(NMHDR *pNMHDR, LRESULT *pResult);
};
