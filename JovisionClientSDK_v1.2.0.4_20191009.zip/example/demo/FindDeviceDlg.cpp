// FindDeviceDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "JCDemo.h"
#include "FindDeviceDlg.h"
#include "afxdialogex.h"

#define WM_REFLASHDEVICELIST WM_USER + 0x201

HWND g_hFindDeviceWnd;
std::vector<JCLanDeviceInfo> g_DeviceInfosList;

void funLanSearchCallback(PJCLanDeviceInfo pDevice)
{
	if(pDevice == NULL)
	{
		PostMessage(g_hFindDeviceWnd, WM_REFLASHDEVICELIST, 0, 0);
	}
	else
	{
		g_DeviceInfosList.push_back(*pDevice);
	}
}

extern CString GetResString(UINT dwKey);

// CFindDeviceDlg �Ի���

IMPLEMENT_DYNAMIC(CFindDeviceDlg, CDialog)

CFindDeviceDlg::CFindDeviceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindDeviceDlg::IDD, pParent)
{

}

CFindDeviceDlg::~CFindDeviceDlg()
{
}

void CFindDeviceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_DEVICELIST, m_lstDeviceList);
}


BEGIN_MESSAGE_MAP(CFindDeviceDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_REFLASHDEVICE, &CFindDeviceDlg::OnBnClickedButtonReflashdevice)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_DEVICELIST, &CFindDeviceDlg::OnNMDblclkListDevicelist)
	ON_MESSAGE(WM_REFLASHDEVICELIST, &CFindDeviceDlg::OnReflashdevicelist)
END_MESSAGE_MAP()


// CFindDeviceDlg ��Ϣ��������


void CFindDeviceDlg::OnBnClickedButtonReflashdevice()
{
	g_DeviceInfosList.clear();

	if(JCSDK_LanSeartchDevice(JCDT_All, 5000))
	{
		GetDlgItem(IDC_BUTTON_REFLASHDEVICE)->EnableWindow(FALSE);
	}
}


void CFindDeviceDlg::OnNMDblclkListDevicelist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;

	if(pNMItemActivate->iItem < 0)
	{
		return;
	}

	m_strIP = m_lstDeviceList.GetItemText(pNMItemActivate->iItem, 1);
	m_strPort = m_lstDeviceList.GetItemText(pNMItemActivate->iItem, 2);

	OnOK();
}


afx_msg LRESULT CFindDeviceDlg::OnReflashdevicelist(WPARAM wParam, LPARAM lParam)
{
	CString str;

	int count = g_DeviceInfosList.size();
	m_lstDeviceList.DeleteAllItems();
	for(int i = 0; i < count; ++i)
	{
		str = g_DeviceInfosList[i].szCloudSEE;
		int nItemID = m_lstDeviceList.InsertItem(m_lstDeviceList.GetItemCount(), str);
		str = g_DeviceInfosList[i].szIP;
		m_lstDeviceList.SetItemText(nItemID, 1, str);
		str.Format(_T("%d"), g_DeviceInfosList[i].nPort);
		m_lstDeviceList.SetItemText(nItemID, 2, str);
		switch(g_DeviceInfosList[i].nDeviceType)
		{
		case JCDT_Card:
			str = _T("Card");
			break;

		case JCDT_DVR:
			str = _T("DVR");
			break;

		case JCDT_IPC:
			str = _T("IPC");
			break;

		case JCDT_NVR:
			str = _T("NVR");
			break;

		default:
			str = _T("Unknown");
			break;
		}
		m_lstDeviceList.SetItemText(nItemID, 3, str);
		str.Format(_T("%d"), g_DeviceInfosList[i].nChannelNum);
		m_lstDeviceList.SetItemText(nItemID, 4, str);
		str = g_DeviceInfosList[i].szDeviceName;
		m_lstDeviceList.SetItemText(nItemID, 5, str);
	}

	GetDlgItem(IDC_BUTTON_REFLASHDEVICE)->EnableWindow(TRUE);

	return 0;
}


BOOL CFindDeviceDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	g_hFindDeviceWnd = GetSafeHwnd();

	m_lstDeviceList.InsertColumn(0, GetResString(IDS_CloudSEEID), 0, 100);
	m_lstDeviceList.InsertColumn(1, _T("IP"), 0, 110);
	m_lstDeviceList.InsertColumn(2, GetResString(IDS_Port), 0, 50);
	m_lstDeviceList.InsertColumn(3, GetResString(IDS_DeviceType), 0, 70);
	m_lstDeviceList.InsertColumn(4, GetResString(IDS_ChannelNum), 0, 50);
	m_lstDeviceList.InsertColumn(5, GetResString(IDS_DeviceName), 0, 212);

	return TRUE;
}
