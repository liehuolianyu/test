﻿
// JCDemoDlg.cpp : 实现文件
//

#include "stdafx.h"
#include "JCDemo.h"
#include "JCDemoDlg.h"
#include "afxdialogex.h"
#include "FindDeviceDlg.h"
#include "RemoteConfigDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CJCDemoDlg 对话

#define WM_JCSDKMSG				WM_USER + 0x010
#define WM_GETPICTURE			WM_USER + 0x011
#define WM_GETRECFILELIST		WM_USER + 0x012
#define WM_RESETSTREAM			WM_USER + 0x013

CJCDemoDlg *g_pMainWnd = NULL;
std::vector<JCRecFileInfo> g_RecFileInfoList;

CString GetResString(UINT dwKey)
{
	TCHAR acBuffer[512] = {0};
	LoadString(AfxGetResourceHandle(), dwKey, acBuffer, 512);

	return acBuffer;
}

CJCDemoDlg::CJCDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CJCDemoDlg::IDD, pParent)
	, m_nLinkID(-1)
	, m_strCloudSEE(_T(""))
	, m_strIP(_T(""))
	, m_nPort(0)
	, m_nChannel(0)
	, m_strPassword(_T(""))
	, m_strUsername(_T(""))
	, m_bPreview(false)
	, m_bDecoding(false)
	, m_bPreviewing(false)
	, m_nSubStream(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	g_pMainWnd = this;
}

void CJCDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CLOUDSEE, m_strCloudSEE);
	DDV_MaxChars(pDX, m_strCloudSEE, 14);
	DDX_Text(pDX, IDC_EDIT_IP, m_strIP);
	DDV_MaxChars(pDX, m_strIP, 15);
	DDX_Text(pDX, IDC_EDIT_PORT, m_nPort);
	DDV_MinMaxInt(pDX, m_nPort, 0, 65535);
	DDX_Control(pDX, IDC_LIST_LOG, m_lstLogs);
	DDX_Control(pDX, IDC_STATIC_SHOWRECT, m_stcShowRect);
	DDX_Text(pDX, IDC_EDIT_CHANNEL, m_nChannel);
	DDV_MinMaxInt(pDX, m_nChannel, 1, 255);
	DDX_Text(pDX, IDC_EDIT_PWD, m_strPassword);
	DDV_MaxChars(pDX, m_strPassword, 20);
	DDX_Text(pDX, IDC_EDIT_USER, m_strUsername);
	DDV_MaxChars(pDX, m_strUsername, 20);
	DDX_Control(pDX, IDC_LIST_RECFILELIST, m_lstRecFileList);
	DDX_Text(pDX, IDC_EDIT_SUB_STREAM, m_nSubStream);
	DDV_MinMaxInt(pDX, m_nSubStream, 1, 8);
}

BEGIN_MESSAGE_MAP(CJCDemoDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, &CJCDemoDlg::OnBnClickedButtonConnect)
	ON_BN_CLICKED(IDC_BUTTON_DISCONNECT, &CJCDemoDlg::OnBnClickedButtonDisconnect)
	ON_BN_CLICKED(IDC_BUTTON_ENABLEDECODE, &CJCDemoDlg::OnBnClickedButtonEnabledecode)
	ON_BN_CLICKED(IDC_BUTTON_DISABLEDECODE, &CJCDemoDlg::OnBnClickedButtonDisabledecode)
	ON_BN_CLICKED(IDC_BUTTON_ENABLEPREVIEW, &CJCDemoDlg::OnBnClickedButtonEnablepreview)
	ON_BN_CLICKED(IDC_BUTTON_DISABLEPREVIEW, &CJCDemoDlg::OnBnClickedButtonDisablepreview)
	ON_BN_CLICKED(IDC_BUTTON_GETPICTURE, &CJCDemoDlg::OnBnClickedButtonGetpicture)
	ON_BN_CLICKED(IDC_BUTTON_STARTREC, &CJCDemoDlg::OnBnClickedButtonStartrec)
	ON_BN_CLICKED(IDC_BUTTON_STOPREC, &CJCDemoDlg::OnBnClickedButtonStoprec)
	ON_BN_CLICKED(IDC_BUTTON_STARTAUDIO, &CJCDemoDlg::OnBnClickedButtonStartaudio)
	ON_BN_CLICKED(IDC_BUTTON_STOPAUDIO, &CJCDemoDlg::OnBnClickedButtonStopaudio)
	ON_MESSAGE(WM_GETPICTURE, &CJCDemoDlg::OnGetpicture)
	ON_BN_CLICKED(IDC_BUTTON_FINDDEVICE, &CJCDemoDlg::OnBnClickedButtonFinddevice)
	ON_WM_SIZE()
	ON_WM_MOVE()
	ON_BN_CLICKED(IDC_BUTTON_SEARCHRECFILE, &CJCDemoDlg::OnBnClickedButtonSearchrecfile)
	ON_MESSAGE(WM_GETRECFILELIST, &CJCDemoDlg::OnGetrecfilelist)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_RECFILELIST, &CJCDemoDlg::OnNMDblclkListRecfilelist)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_RECFILELIST, &CJCDemoDlg::OnNMRClickListRecfilelist)
	ON_MESSAGE(WM_RESETSTREAM, &CJCDemoDlg::OnResetstream)
	ON_BN_CLICKED(IDC_BUTTON_REMOTECFG, &CJCDemoDlg::OnBnClickedButtonRemotecfg)
	ON_BN_CLICKED(IDC_BUTTON_SPEEDUP, &CJCDemoDlg::OnBnClickedButtonSpeedup)
	ON_BN_CLICKED(IDC_BUTTON_SPEEDDOWN, &CJCDemoDlg::OnBnClickedButtonSpeeddown)
	ON_BN_CLICKED(IDC_BUTTON_SPEEDNORMAL, &CJCDemoDlg::OnBnClickedButtonSpeednormal)
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD, &CJCDemoDlg::OnBnClickedButtonDownload)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE, &CJCDemoDlg::OnBnClickedButtonPause)
	ON_BN_CLICKED(IDC_BUTTON_PTZLEFT, &CJCDemoDlg::OnBnClickedButtonPtzleft)
	ON_BN_CLICKED(IDC_BUTTON_PTZRIGHT, &CJCDemoDlg::OnBnClickedButtonPtzright)
	ON_BN_CLICKED(IDC_BUTTON_GETYSTONLINESTATUS, &CJCDemoDlg::OnBnClickedButtonGetystonlinestatus)
	ON_BN_CLICKED(IDC_CHECK_YST2, &CJCDemoDlg::OnBnClickedCheckYst2)
END_MESSAGE_MAP()

char *g_szRecFilename = "Video.mp4";
bool s_bDownload = false;

void funJCEventCallback(JCLink_t nLinkID, JCEventType etType, DWORD_PTR pData1, DWORD_PTR pData2, LPVOID pUserData)
{
	DWORD dwMsgID = 0;
	bool bBeginDownload = false;

	switch(etType)
	{
	case JCET_GetFileListOK://获取远程录像成功
		{
			g_RecFileInfoList.clear();
			PJCRecFileInfo pInfos = (PJCRecFileInfo)pData1;
			int nCount = (int)pData2;
			for(int i = 0; i < nCount; ++i)
			{
				g_RecFileInfoList.push_back(pInfos[i]);
			}
		}
	case JCET_GetFileListError://获取远程录像失败
		{
			g_pMainWnd->PostMessage(WM_GETRECFILELIST, etType == JCET_GetFileListOK);
		}
		return;
		break;

	case JCET_StreamReset://码流重置信号
		{
			JCSDK_EnableDecoder(nLinkID, FALSE);
			g_pMainWnd->PostMessage(WM_RESETSTREAM);
		}
		return;
		break;
	}

	switch(etType)
	{
	case JCET_ConnectOK://连接成功
		dwMsgID = IDS_ConnectOK;
		break;

	case JCET_UserAccessError: //用户验证失败
		dwMsgID = IDS_ConnectAccessError;
		break;

	case JCET_NoChannel://主控通道未开启
		dwMsgID = IDS_ConnectNoChannel;
		break;

	case JCET_ConTypeError://连接类型错误
		dwMsgID = IDS_ConnectTypeError;
		break;

	case JCET_ConCountLimit://超过主控连接最大数
		dwMsgID = IDS_ConnectCountLimit;
		break;

	case JCET_ConTimeout://连接超时
		dwMsgID = IDS_ConnectTimeout;
		break;

	case JCET_DisconOK://断开连接成功
		dwMsgID = IDS_DisconnectOK;
		break;

	case JCET_ConAbout://连接异常断开
		dwMsgID = IDS_DisconnectError;
		break;

	case JCET_ServiceStop://主控断开连接
		dwMsgID = IDS_ServerStop;
		break;

	default:
		return;
		break;
	}

	CString strMsg;
	std::wstring wMsg;
	if(pData1 != NULL)
	{
		std::string sMsg = (char*)pData1;
		wMsg = std::wstring(sMsg.begin(), sMsg.end());
	}
	strMsg.Format(GetResString(dwMsgID), nLinkID, wMsg.c_str());
	g_pMainWnd->AddLogItem(strMsg);
}

void funJCDataCallback(JCLink_t nLinkID, PJCStreamFrame pFrame, LPVOID pUserData)
{
	char acBuffer[64];
	sprintf(acBuffer, "Type:%d Size:%d %2.2X %2.2X %2.2X %2.2X %2.2X\n", pFrame->sType, pFrame->nFrameSize,
		pFrame->pFrameData[0], pFrame->pFrameData[1], pFrame->pFrameData[2], pFrame->pFrameData[3], pFrame->pFrameData[4]);
	OutputDebugStringA(acBuffer);
}

bool g_bDownloading = false;

void funJCDownloadDataCallback(JCLink_t nLinkID, JCDownloadEventType etType, DWORD dwProgress, DWORD dwFileSize, LPVOID pUserData)
{
	DWORD dwMsgID = 0;

	switch(etType)
	{
	case JCDET_DownloadData://录像下载数据
		if(!g_bDownloading)
		{
            g_bDownloading = true;
			dwMsgID = IDS_BeginDownload;
		}
		else
		{
			return;
		}
		break;

	case JCDET_DownloadEnd://录像下载完成
		dwMsgID = IDS_DownloadOver;
		break;

	case JCDET_DownloadStop://录像下载停止
		dwMsgID = IDS_DownloadStop;
		break;

	case JCDET_DownloadError://远程下载失败
		dwMsgID = IDS_DownloadFailed;
		break;

	case JCDET_DownloadTimeout://远程下载超时
		dwMsgID = IDS_DownloadTimeout;
		break;

	default:
		return;
		break;
	}

	CString strMsg;
	std::wstring wMsg;
	strMsg.Format(GetResString(dwMsgID), nLinkID, wMsg.c_str());
	g_pMainWnd->AddLogItem(strMsg);
}

bool g_bGetPicture = false;
char *g_szPictureFilename = "pic.bmp";

inline UCHAR Clip(int num)
{
	return (UCHAR)(((num) > 255)?255:(((num) < 0)?0:(num)));
}

inline UCHAR GetR(int y, int u, int v)
{
	return Clip((298 * (y - 16) + 409 * (v - 128) + 128) >> 8);
}

inline UCHAR GetG(int y, int u, int v)
{
	return Clip((298 * (y - 16) - 100 * (u - 128) - 208 * (v - 128) + 128) >> 8);
}

inline UCHAR GetB(int y, int u, int v)
{
	return Clip((298 * (y - 16) + 516 * (u - 128) + 128) >> 8);
}

void yv12_to_rgb32(PUCHAR pDest, DWORD dwDestPitch, PUCHAR pSrcY, PUCHAR pSrcU, PUCHAR pSrcV, 
	DWORD dwSrcYPitch, DWORD dwSrcUPitch, DWORD dwSrcVPitch, DWORD dwWidth, DWORD dwHeight)
{
	pDest += 4 * dwWidth * (dwHeight - 1);

	int nYCount = dwHeight / 2;
	int nXCount = dwWidth / 2;
	for(DWORD y = 0; y < dwHeight; ++y)
	{
		PUCHAR pDestLine = pDest;
		PUCHAR pSrcYLine = pSrcY;
		PUCHAR pSrcULine = pSrcU;
		PUCHAR pSrcVLine = pSrcV;

		for(int x = 0; x < nXCount; ++x)
		{
			*(pDestLine++) = GetB(*pSrcYLine, *pSrcULine, *pSrcVLine);
			*(pDestLine++) = GetG(*pSrcYLine, *pSrcULine, *pSrcVLine);
			*(pDestLine++) = GetR(*pSrcYLine, *pSrcULine, *pSrcVLine);
			*(pDestLine++) = 255;

			++pSrcYLine;

			*(pDestLine++) = GetB(*pSrcYLine, *pSrcULine, *pSrcVLine);
			*(pDestLine++) = GetG(*pSrcYLine, *pSrcULine, *pSrcVLine);
			*(pDestLine++) = GetR(*pSrcYLine, *pSrcULine, *pSrcVLine);
			*(pDestLine++) = 255;

			++pSrcYLine;
			++pSrcULine;
			++pSrcVLine;
		}

		pDest -= dwDestPitch;
		pSrcY += dwSrcYPitch;
		if(y % 2 == 1)
		{
			pSrcU += dwSrcUPitch;
			pSrcV += dwSrcVPitch;
		}
	}
}

void funJCRawDataCallback(JCLink_t nLinkID, PJCRawFrame pFrame, LPVOID pUserData)
{
}

extern void funLanSearchCallback(PJCLanDeviceInfo pDevice);

// CJCDemoDlg 消息处理程序

BOOL CJCDemoDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	m_lstLogs.InsertColumn(0, _T(""), 0, 300);
	m_lstLogs.SetScrollRange(SB_VERT, 0, 100);
	m_strCloudSEE = _T("12221SSS15CG");//_T("A361");
	m_strIP = _T("172.16.16.250");
	m_nPort = 9101;
	m_nChannel = 1;
	m_nSubStream = 1;
	m_strUsername = _T("abc");
	m_strPassword = _T("123");
	//((CButton*)GetDlgItem(IDC_RADIO_CLOUDSEE))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_RADIO_IPMODE))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK_YST2))->SetCheck(FALSE);
	OnBnClickedCheckYst2();
	UpdateData(FALSE);

	m_lstRecFileList.InsertColumn(0, GetResString(IDS_Filename), 0, 300);

	if(!JCSDK_InitSDK(-1, NULL))
	{
		AfxMessageBox(GetResString(IDS_InitSDKError));
		PostQuitMessage(-1);
	}

	JCSDK_RegisterCallback(funJCEventCallback, funJCDataCallback, funJCDownloadDataCallback, funJCRawDataCallback, funLanSearchCallback);

	AddLogItem(GetResString(IDS_InitOK));
		
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CJCDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CJCDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CJCDemoDlg::AddLogItem(CString str)
{
	m_lstLogs.InsertItem(m_lstLogs.GetItemCount(), str);
	m_lstLogs.SetScrollPos(SB_VERT, 100);
}


void CJCDemoDlg::OnBnClickedButtonConnect()
{
	UpdateData(TRUE);

	if(m_nLinkID != -1)
	{
		JCSDK_Disconnect(m_nLinkID);
	}

	std::wstring wstr = m_strCloudSEE.GetBuffer();
	std::string strCloudSEE = std::string(wstr.begin(), wstr.end());
	wstr = m_strIP.GetBuffer();
	std::string strIP = std::string(wstr.begin(), wstr.end());
	wstr = m_strUsername.GetBuffer();
	std::string strUser = std::string(wstr.begin(), wstr.end());
	wstr = m_strPassword.GetBuffer();
	std::string strPwd = std::string(wstr.begin(), wstr.end());
	JDeviceProduct nProduct = ((CButton*)GetDlgItem(IDC_CHECK_YST2))->GetCheck() ? JDP_CloudSEE2 : JDP_CloudSEE;

	if(((CButton*)GetDlgItem(IDC_RADIO_CLOUDSEE))->GetCheck())
	{
		m_nLinkID = JCSDK_Connect2(nProduct, (char*)strCloudSEE.c_str(), 0, m_nChannel, m_nSubStream, 
			(char*)strUser.c_str(), (char*)strPwd.c_str(), TRUE, NULL);
	}
	else
	{
		m_nLinkID = JCSDK_Connect2(nProduct, (char*)strIP.c_str(), m_nPort, m_nChannel, m_nSubStream,
			(char*)strUser.c_str(), (char*)strPwd.c_str(), FALSE, NULL);
	}

	if(m_nLinkID == -1)
	{
		AddLogItem(GetResString(IDS_ConnectError));
	}
	else
	{
		CString strMsg;
		strMsg.Format(GetResString(IDS_Connecting), m_nLinkID);
		AddLogItem(strMsg);
	}
}


void CJCDemoDlg::OnBnClickedButtonDisconnect()
{
	JCSDK_Disconnect(m_nLinkID);
	m_bDecoding = false;
	m_bPreviewing = false;
}


void CJCDemoDlg::OnBnClickedButtonEnabledecode()
{
	UINT dwMsgID = 0;
	if(JCSDK_EnableDecoder(m_nLinkID, TRUE))
	{
		dwMsgID = IDS_EnableDecodeOK;
		m_bDecoding = true;
	}
	else
	{
		dwMsgID = IDS_EnableDecodeError;
		m_bDecoding = false;
		m_bPreviewing = false;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


void CJCDemoDlg::OnBnClickedButtonDisabledecode()
{
	UINT dwMsgID = 0;
	if(JCSDK_EnableDecoder(m_nLinkID, FALSE))
	{
		dwMsgID = IDS_DisableDecodeOK;
	}
	else
	{
		dwMsgID = IDS_DisableDecodeError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);

	m_bDecoding = false;
	m_bPreviewing = false;
}


void CJCDemoDlg::OnBnClickedButtonEnablepreview()
{
	RECT rtRect = {0};
	m_stcShowRect.GetClientRect(&rtRect);
	m_stcShowRect.ClientToScreen(&rtRect);

	UINT dwMsgID = 0;
	if(JCSDK_SetVideoPreview(m_nLinkID, m_stcShowRect.GetSafeHwnd(), &rtRect))
	{
		dwMsgID = IDS_EnablePreviewOK;
		m_bPreview = true;
		m_bPreviewing = true;
	}
	else
	{
		dwMsgID = IDS_EnablePreviewError;
		m_bPreview = false;
		m_bPreviewing = false;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


void CJCDemoDlg::OnBnClickedButtonDisablepreview()
{
	UINT dwMsgID = 0;
	if(JCSDK_SetVideoPreview(m_nLinkID, NULL, NULL))
	{
		dwMsgID = IDS_DisablePreviewOK;
	}
	else
	{
		dwMsgID = IDS_DisablePreviewError;
	}
	m_bPreview = false;
	m_bPreviewing = false;

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


void CJCDemoDlg::OnBnClickedButtonGetpicture()
{
	PostMessage(WM_GETPICTURE, JCSDK_SaveBitmap(m_nLinkID, g_szPictureFilename));
}


void CJCDemoDlg::OnBnClickedButtonStartrec()
{
	std::string szFilename;
	JCStreamInfo info;
	if(JCSDK_GetStreamInfo(m_nLinkID, &info))
	{
		switch(info.eRecFileType)
		{
		case JCRT_SV4:
			szFilename = "007.sv4";
			break;

		case JCRT_SV5:
			szFilename = "007.sv5";
			break;

		case JCRT_SV6:
			szFilename = "007.sv6";
			break;

		case JCRT_MP4:
		case JCRT_JVFS:
			szFilename = "007.mp4";
			break;
		}
	}

	UINT dwMsgID = 0;
	if(szFilename.empty())
	{
		dwMsgID = IDS_StartRecError;
	}
	else if(JCSDK_StartRec(m_nLinkID, (char*)szFilename.c_str()))
	{
		dwMsgID = IDS_StartRecOK;
	}
	else
	{
		dwMsgID = IDS_StartRecError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


void CJCDemoDlg::OnBnClickedButtonStoprec()
{
	UINT dwMsgID = 0;
	if(JCSDK_StopRec(m_nLinkID))
	{
		dwMsgID = IDS_StopRecOK;
	}
	else
	{
		dwMsgID = IDS_StopRecError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


void CJCDemoDlg::OnBnClickedButtonStartaudio()
{
	UINT dwMsgID = 0;
	if(JCSDK_SetAudioPreview(m_nLinkID, m_stcShowRect.GetSafeHwnd()))
	{
		dwMsgID = IDS_StartAudioOK;
	}
	else
	{
		dwMsgID = IDS_StartAudioError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


void CJCDemoDlg::OnBnClickedButtonStopaudio()
{
	UINT dwMsgID = 0;
	if(JCSDK_SetAudioPreview(m_nLinkID, NULL))
	{
		dwMsgID = IDS_StopAudioOK;
	}
	else
	{
		dwMsgID = IDS_StopAudioError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


afx_msg LRESULT CJCDemoDlg::OnGetpicture(WPARAM wParam, LPARAM lParam)
{
	int nMsg = 0;
	CString filename;
	nMsg = wParam ? IDS_GetPictureOK : IDS_GetPictureError;
	filename = g_szPictureFilename;

	CString msg;
	msg.Format(GetResString(nMsg), m_nLinkID, filename);
	AddLogItem(msg);

	return 0;
}


void CJCDemoDlg::OnBnClickedButtonFinddevice()
{
	CFindDeviceDlg dlg;
	if(dlg.DoModal() == IDOK)
	{
		GetDlgItem(IDC_EDIT_IP)->SetWindowText(dlg.m_strIP);
		GetDlgItem(IDC_EDIT_PORT)->SetWindowText(dlg.m_strPort);
		((CButton*)GetDlgItem(IDC_RADIO_CLOUDSEE))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_IPMODE))->SetCheck(TRUE);
	}
}


void CJCDemoDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if(m_bPreview)
	{
		RECT rtRect = {0};
		m_stcShowRect.GetClientRect(&rtRect);
		m_stcShowRect.ClientToScreen(&rtRect);
		JCSDK_SetVideoPreview(m_nLinkID, m_stcShowRect.GetSafeHwnd(), &rtRect);
	}
}


void CJCDemoDlg::OnMove(int x, int y)
{
	CDialogEx::OnMove(x, y);

	if(m_bPreview)
	{
		RECT rtRect = {0};
		m_stcShowRect.GetClientRect(&rtRect);
		m_stcShowRect.ClientToScreen(&rtRect);
		JCSDK_SetVideoPreview(m_nLinkID, m_stcShowRect.GetSafeHwnd(), &rtRect);
	}
}


void CJCDemoDlg::OnBnClickedButtonSearchrecfile()
{
	UINT dwMsgID = 0;
	JCDateBlock data;
	time_t t;
	time(&t);
	tm d = {0};
	localtime_s(&d, &t);
	data.nBeginYear = data.nEndYear = d.tm_year + 1900;
	data.nBeginMonth = data.nEndMonth = d.tm_mon + 1;
	data.nBeginDay = data.nEndDay = d.tm_mday;

	if(JCSDK_GetRemoteRecFileList(m_nLinkID, &data))
	{
		return;
	}
	else
	{
		dwMsgID = IDS_GetRecFileListError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);
}


afx_msg LRESULT CJCDemoDlg::OnGetrecfilelist(WPARAM wParam, LPARAM lParam)
{
	DWORD dwMsgID = 0;
	if(wParam)
	{
		m_lstRecFileList.DeleteAllItems();
		int nCount = g_RecFileInfoList.size();
		for(int i = 0; i < nCount; ++i)
		{
			std::string str = g_RecFileInfoList[i].szPathName;
			std::wstring wstr(str.begin(), str.end());
			int nItemID = m_lstRecFileList.InsertItem(m_lstRecFileList.GetItemCount(), wstr.c_str());
			m_lstRecFileList.SetItemData(nItemID, g_RecFileInfoList[i].nRecFileID);
		}

		dwMsgID = nCount == 0 ? IDS_NoRecFile : IDS_GetRecFileListOK;
	}
	else
	{
		dwMsgID = IDS_GetRecFileListError;
	}

	CString strMsg;
	strMsg.Format(GetResString(dwMsgID), m_nLinkID);
	AddLogItem(strMsg);

	return 0;
}


void CJCDemoDlg::OnNMDblclkListRecfilelist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	if(pNMItemActivate->iItem >= 0)
	{
		int nFileID = m_lstRecFileList.GetItemData(pNMItemActivate->iItem);
		if(nFileID >= 0)
		{
			JCSDK_RemotePlay(m_nLinkID, nFileID);
		}
	}

	*pResult = 0;
}


void CJCDemoDlg::OnNMRClickListRecfilelist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	*pResult = 0;
}


afx_msg LRESULT CJCDemoDlg::OnResetstream(WPARAM wParam, LPARAM lParam)
{
	if(m_bDecoding)
	{
		JCSDK_EnableDecoder(m_nLinkID, TRUE);
		if(m_bPreviewing)
		{
			RECT rtRect = {0};
			m_stcShowRect.GetClientRect(&rtRect);
			m_stcShowRect.ClientToScreen(&rtRect);

			JCSDK_SetVideoPreview(m_nLinkID, m_stcShowRect.GetSafeHwnd(), &rtRect);
		}
	}

	return 0;
}


void CJCDemoDlg::OnBnClickedButtonRemotecfg()
{
	//JCSDK_RemoteConfig(m_nLinkID, 0);
	if(JCSDK_GRPC_Begin(m_nLinkID))
	{
		CRemoteConfigDlg dlg(m_nLinkID);
		dlg.DoModal();
		JCSDK_GRPC_End(m_nLinkID);
	}
	else
	{
		AfxMessageBox(_T("远程设置失败!"));
	}
}


void CJCDemoDlg::OnBnClickedButtonSpeedup()
{
	JCSDK_RemotePlayControl(m_nLinkID, JCRPC_SpeedUp, 0);
}


void CJCDemoDlg::OnBnClickedButtonSpeeddown()
{
	JCSDK_RemotePlayControl(m_nLinkID, JCRPC_SpeedDown, 0);
}


void CJCDemoDlg::OnBnClickedButtonSpeednormal()
{
	JCSDK_RemotePlayControl(m_nLinkID, JCRPC_SpeedNormal, 0);
}


void CJCDemoDlg::OnBnClickedButtonDownload()
{
	if(s_bDownload)
	{
        if(g_bDownloading)
		{
			CString strMsg;
			strMsg.Format(GetResString(IDS_DownloadStop), m_nLinkID);
			AddLogItem(strMsg);
            g_bDownloading = false;
		}

		JCSDK_DownloadRemoteFile(m_nLinkID, -1, NULL);
		SetDlgItemText(IDC_BUTTON_DOWNLOAD, _T("下载"));
	}
	else
	{
        g_bDownloading = false;
        int nIndex = m_lstRecFileList.GetNextItem(-1, LVIS_SELECTED);
		JCSDK_DownloadRemoteFile(m_nLinkID, nIndex, g_szRecFilename);
		SetDlgItemText(IDC_BUTTON_DOWNLOAD, _T("停止下载"));
	}
	s_bDownload = !s_bDownload;
}


void CJCDemoDlg::OnBnClickedButtonPause()
{
	static bool s_bPause = false;
	if(s_bPause)
	{
		JCSDK_RemotePlayControl(m_nLinkID, JCRPC_Play, 0);
		SetDlgItemText(IDC_BUTTON_PAUSE, _T("暂停"));
	}
	else
	{
		JCSDK_RemotePlayControl(m_nLinkID, JCRPC_Pause, 0);
		SetDlgItemText(IDC_BUTTON_PAUSE, _T("播放"));
	}
	s_bPause = !s_bPause;
}


void CJCDemoDlg::OnBnClickedButtonPtzleft()
{
	static bool s_bRun = false;
	s_bRun = !s_bRun;
	if(s_bRun)
	{
		JCSDK_SendPTZCommand(m_nLinkID, JCPCT_Left, TRUE);
		SetDlgItemText(IDC_BUTTON_PTZLEFT, _T("停止左转"));
	}
	else
	{
		JCSDK_SendPTZCommand(m_nLinkID, JCPCT_Left, FALSE);
		SetDlgItemText(IDC_BUTTON_PTZLEFT, _T("云台左转"));
	}
}


void CJCDemoDlg::OnBnClickedButtonPtzright()
{
	static bool s_bRun = false;
	s_bRun = !s_bRun;
	if(s_bRun)
	{
		JCSDK_SendPTZCommand(m_nLinkID, JCPCT_Right, TRUE);
		SetDlgItemText(IDC_BUTTON_PTZRIGHT, _T("停止右转"));
	}
	else
	{
		JCSDK_SendPTZCommand(m_nLinkID, JCPCT_Right, FALSE);
		SetDlgItemText(IDC_BUTTON_PTZRIGHT, _T("云台右转"));
	}
}


void CJCDemoDlg::OnBnClickedButtonGetystonlinestatus()
{
	UpdateData(TRUE);
	std::wstring wstr = m_strCloudSEE.GetBuffer();
	std::string strCloudSEE = std::string(wstr.begin(), wstr.end());
	int nRet = JCSDK_GetYstOnlineStatus((char*)strCloudSEE.c_str(), 5);
	if(nRet > 0)
	{
		AfxMessageBox(_T("设备在线"));
	}
	else if(nRet == 0)
	{
		AfxMessageBox(_T("设备不在线"));
	}
	else
	{
		AfxMessageBox(_T("查询失败"));
	}
}


void CJCDemoDlg::OnBnClickedCheckYst2()
{
	if(((CButton*)GetDlgItem(IDC_CHECK_YST2))->GetCheck())
	{
		m_nPort = 18320;
		GetDlgItem(IDC_EDIT_SUB_STREAM)->EnableWindow(TRUE);
	}
	else
	{
		m_nPort = 9101;
		GetDlgItem(IDC_EDIT_SUB_STREAM)->EnableWindow(FALSE);
	}
	UpdateData(FALSE);
}
