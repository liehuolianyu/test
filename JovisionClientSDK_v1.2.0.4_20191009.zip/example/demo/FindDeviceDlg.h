#pragma once
#include "afxcmn.h"


// CFindDeviceDlg �Ի���

class CFindDeviceDlg : public CDialog
{
	DECLARE_DYNAMIC(CFindDeviceDlg)

public:
	CFindDeviceDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CFindDeviceDlg();

// �Ի�������
	enum { IDD = IDD_FINDDEVICEDLG };

	CString m_strIP;
	CString m_strPort;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_lstDeviceList;
	afx_msg void OnBnClickedButtonReflashdevice();
	afx_msg void OnNMDblclkListDevicelist(NMHDR *pNMHDR, LRESULT *pResult);
protected:
	afx_msg LRESULT OnReflashdevicelist(WPARAM wParam, LPARAM lParam);
public:
	virtual BOOL OnInitDialog();
};
