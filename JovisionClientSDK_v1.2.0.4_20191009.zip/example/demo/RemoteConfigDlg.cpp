// RemoteConfigDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "JCDemo.h"
#include "RemoteConfigDlg.h"
#include "afxdialogex.h"
#include "JCSDK.h"


std::string ToUTF8(CString str)
{
	std::string strRet;

	char *pacBuffer = NULL;
	int bufferLength = WideCharToMultiByte(CP_UTF8, 0, str, -1, NULL, 0, 0, NULL);
	if(bufferLength > 0)
	{
		pacBuffer = new char[bufferLength + 1];
		memset(pacBuffer, 0, bufferLength + 1);
		if(WideCharToMultiByte(CP_UTF8, 0, str, -1, pacBuffer, bufferLength, 0, NULL) != bufferLength)
		{
			delete[] pacBuffer;
		}
		strRet = pacBuffer;
		delete[] pacBuffer;
	}

	return strRet;
}

CString FromUTF8(const char* src)
{
	if(!src)
	{
		return _T("");
	}

	std::string str(src);
	CString strRet;

	wchar_t *pacwBuffer = NULL;
	int wbufferLength = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);
	if(wbufferLength > 0)
	{
		pacwBuffer = new wchar_t[wbufferLength + 1];
		memset(pacwBuffer, 0, wbufferLength + 1);
		if(MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, pacwBuffer, wbufferLength) != wbufferLength)
		{
			delete[] pacwBuffer;
		}
		strRet = pacwBuffer;
		delete[] pacwBuffer;
	}

	return strRet;
}


// CRemoteConfigDlg �Ի���

IMPLEMENT_DYNAMIC(CRemoteConfigDlg, CDialog)

CRemoteConfigDlg::CRemoteConfigDlg(int nLinkID, CWnd* pParent /*=NULL*/)
: CDialog(CRemoteConfigDlg::IDD, pParent), m_nLinkID(nLinkID)
, m_strUsername(_T(""))
, m_strUserDesc(_T(""))
, m_strPassword(_T(""))
{

}

CRemoteConfigDlg::~CRemoteConfigDlg()
{
}

void CRemoteConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NETUSERDESC, m_strUserDesc);
	DDX_Text(pDX, IDC_EDIT_NETUSERNAME, m_strUsername);
	DDX_Text(pDX, IDC_EDIT_NETUSERPWD, m_strPassword);
	DDX_Control(pDX, IDC_LIST_USERLIST, m_lstUserList);
	DDX_Control(pDX, IDC_COMBO_NETUSERLEVEL, m_cbUserLevel);
}


BEGIN_MESSAGE_MAP(CRemoteConfigDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_GETUSERS, &CRemoteConfigDlg::OnBnClickedButtonGetusers)
	ON_BN_CLICKED(IDC_BUTTON_ADDUSER, &CRemoteConfigDlg::OnBnClickedButtonAdduser)
	ON_BN_CLICKED(IDC_BUTTON_DELETEUSER, &CRemoteConfigDlg::OnBnClickedButtonDeleteuser)
	ON_BN_CLICKED(IDC_BUTTON_MODIFYUSER, &CRemoteConfigDlg::OnBnClickedButtonModifyuser)
	ON_NOTIFY(NM_CLICK, IDC_LIST_USERLIST, &CRemoteConfigDlg::OnNMClickListUserlist)
END_MESSAGE_MAP()


// CRemoteConfigDlg ��Ϣ��������


BOOL CRemoteConfigDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_lstUserList.InsertColumn(0, _T("�û���"), 0, 150);
	m_lstUserList.InsertColumn(1, _T("Ȩ��"), 0, 150);
	m_lstUserList.InsertColumn(2, _T("˵��"), 0, 150);

	m_cbUserLevel.AddString(_T("admin"));
	m_cbUserLevel.AddString(_T("operator"));
	m_cbUserLevel.AddString(_T("user"));
	m_cbUserLevel.AddString(_T("anonymous"));
	m_cbUserLevel.AddString(_T("extended"));

	OnBnClickedButtonGetusers();

	return TRUE;
}


void CRemoteConfigDlg::OnBnClickedButtonGetusers()
{
	m_lstUserList.DeleteAllItems();

	PARAM_REQ_sdk_account_get_users req;
	PARAM_RESP_sdk_account_get_users resp;
	if(JCSDK_GRPC_account_get_users(m_nLinkID, &req, &resp))
	{
		for(int i = 0; i < resp.users_cnt; ++i)
		{
			m_lstUserList.InsertItem(i, FromUTF8(resp.users[i].name));
			m_lstUserList.SetItemText(i, 1, FromUTF8(resp.users[i].level));
			m_lstUserList.SetItemText(i, 2, FromUTF8(resp.users[i].description));
		}
	}
	else
	{
		AfxMessageBox(_T("ˢ���б�ʧ�ܣ�"));
	}
}


void CRemoteConfigDlg::OnBnClickedButtonAdduser()
{
	UpdateData(TRUE);

	std::string strUsername = ToUTF8(m_strUsername);
	std::string strPassword = ToUTF8(m_strPassword);
	std::string strDesc = ToUTF8(m_strUserDesc);
	std::string strLevel;
	switch(m_cbUserLevel.GetCurSel())
	{
	case 0:
		strLevel = "admin";
		break;

	case 1:
		strLevel = "operator";
		break;

	case 2:
		strLevel = "user";
		break;

	case 3:
		strLevel = "anonymous";
		break;

	case 4:
		strLevel = "extended";
		break;
	}

	PARAM_REQ_sdk_account_add_user req;
	PARAM_RESP_sdk_account_add_user resq;
	req.name = (char*)strUsername.c_str();
	req.passwd = (char*)strPassword.c_str();
	req.level = (char*)strLevel.c_str();
	req.description = (char*)strDesc.c_str();
	if(JCSDK_GRPC_account_add_user(m_nLinkID, &req, &resq))
	{
		AfxMessageBox(_T("�����û��ɹ���"));
	}
	else
	{
		AfxMessageBox(_T("�����û�ʧ�ܣ�"));
	}
}


void CRemoteConfigDlg::OnBnClickedButtonDeleteuser()
{
	UpdateData(TRUE);
	std::string strUsername;
	for(int i = 0; i < m_lstUserList.GetItemCount(); ++i)
	{
		if(m_lstUserList.GetCheck(i))
		{
			strUsername = ToUTF8(m_lstUserList.GetItemText(i, 0));
		}
	}

	PARAM_REQ_sdk_account_del_user req;
	PARAM_RESP_sdk_account_del_user resq;
	req.name = (char*)strUsername.c_str();
	if(JCSDK_GRPC_account_del_user(m_nLinkID, &req, &resq))
	{
		AfxMessageBox(_T("ɾ���û��ɹ���"));
	}
	else
	{
		AfxMessageBox(_T("ɾ���û�ʧ�ܣ�"));
	}
}


void CRemoteConfigDlg::OnBnClickedButtonModifyuser()
{
	UpdateData(TRUE);

	std::string strUsername = ToUTF8(m_strUsername);
	std::string strPassword = ToUTF8(m_strPassword);
	std::string strDesc = ToUTF8(m_strUserDesc);
	std::string strLevel;
	switch(m_cbUserLevel.GetCurSel())
	{
	case 0:
		strLevel = "admin";
		break;

	case 1:
		strLevel = "operator";
		break;

	case 2:
		strLevel = "user";
		break;

	case 3:
		strLevel = "anonymous";
		break;

	case 4:
		strLevel = "extended";
		break;
	}

	PARAM_REQ_sdk_account_modify_user req;
	PARAM_RESP_sdk_account_modify_user resq;
	req.name = (char*)strUsername.c_str();
	req.passwd = (char*)strPassword.c_str();
	req.level = (char*)strLevel.c_str();
	req.description = (char*)strDesc.c_str();
	if(JCSDK_GRPC_account_modify_user(m_nLinkID, &req, &resq))
	{
		AfxMessageBox(_T("�޸��û��ɹ���"));
	}
	else
	{
		AfxMessageBox(_T("�޸��û�ʧ�ܣ�"));
	}
}


void CRemoteConfigDlg::OnNMClickListUserlist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;

	int nIndex = pNMItemActivate->iItem;
	if(nIndex < 0 || nIndex >= m_lstUserList.GetItemCount())
	{
		m_strUsername = _T("");
		m_strPassword = _T("");
		m_strUserDesc = _T("");
		m_cbUserLevel.SetCurSel(0);
	}
	else
	{
		m_strUsername = m_lstUserList.GetItemText(nIndex, 0);
		m_strPassword = _T("******");
		m_strUserDesc = m_lstUserList.GetItemText(nIndex, 2);
		CString strLevel = m_lstUserList.GetItemText(nIndex, 1);
		if(strLevel == _T("admin"))
		{
			m_cbUserLevel.SetCurSel(0);
		}
		else if(strLevel == _T("operator"))
		{
			m_cbUserLevel.SetCurSel(1);
		}
		else if(strLevel == _T("user"))
		{
			m_cbUserLevel.SetCurSel(2);
		}
		else if(strLevel == _T("anonymous"))
		{
			m_cbUserLevel.SetCurSel(3);
		}
		else if(strLevel == _T("extended"))
		{
			m_cbUserLevel.SetCurSel(4);
		}
		else
		{
			m_cbUserLevel.SetCurSel(-1);
		}
	}

	UpdateData(FALSE);
}
