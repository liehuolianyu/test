
// JCDemoDlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

// CJCDemoDlg �Ի���
class CJCDemoDlg : public CDialogEx
{
// ����
public:
	CJCDemoDlg(CWnd* pParent = NULL);	// ��׼���캯��

	void AddLogItem(CString str);

// �Ի�������
	enum { IDD = IDD_JCDEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	JCLink_t m_nLinkID;
	bool m_bPreview;
	bool m_bDecoding;
	bool m_bPreviewing;

	CString m_strCloudSEE;
	CString m_strIP;
	int m_nPort;
	CListCtrl m_lstLogs;
	CStatic m_stcShowRect;
	afx_msg void OnBnClickedButtonConnect();
	afx_msg void OnBnClickedButtonDisconnect();
	int m_nChannel;
	CString m_strPassword;
	CString m_strUsername;
	afx_msg void OnBnClickedButtonEnabledecode();
	afx_msg void OnBnClickedButtonDisabledecode();
	afx_msg void OnBnClickedButtonEnablepreview();
	afx_msg void OnBnClickedButtonDisablepreview();
	afx_msg void OnBnClickedButtonGetpicture();
	afx_msg void OnBnClickedButtonStartrec();
	afx_msg void OnBnClickedButtonStoprec();
	afx_msg void OnBnClickedButtonStartaudio();
	afx_msg void OnBnClickedButtonStopaudio();
protected:
	afx_msg LRESULT OnGetpicture(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnBnClickedButtonFinddevice();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnBnClickedButtonSearchrecfile();
	CListCtrl m_lstRecFileList;
protected:
	afx_msg LRESULT OnGetrecfilelist(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnNMDblclkListRecfilelist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMRClickListRecfilelist(NMHDR *pNMHDR, LRESULT *pResult);
protected:
	afx_msg LRESULT OnResetstream(WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnBnClickedButtonRemotecfg();
	afx_msg void OnBnClickedButtonSpeedup();
	afx_msg void OnBnClickedButtonSpeeddown();
	afx_msg void OnBnClickedButtonSpeednormal();
	afx_msg void OnBnClickedButtonDownload();
	afx_msg void OnBnClickedButtonPause();
	afx_msg void OnBnClickedButtonPtzleft();
	afx_msg void OnBnClickedButtonPtzright();
	afx_msg void OnBnClickedButtonGetystonlinestatus();
	afx_msg void OnBnClickedCheckYst2();
	int m_nSubStream;
};
